import os
import subprocess
import sys

if os.name == "nt":
    try:
        import curses
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "windows-curses"])
        import curses
else:
    import curses


def main(stdscr):
    curses.curs_set(0)
    stdscr.keypad(True)



    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../systems")
    files = [f for f in os.listdir(path) if f.endswith(".py")]
    files.sort()
    files = [os.path.splitext(file)[0] for file in files]

    selected = 0

    while True:
        stdscr.clear()
        stdscr.addstr(0, 0, "===== KilluBoot v1.0 =====\n\n")

        for idx, file in enumerate(files):
            if idx == selected:
                stdscr.addstr(f"> {file}\n", curses.A_REVERSE)
            else:
                stdscr.addstr(f"  {file}\n")

        key = stdscr.getch()

        if key == curses.KEY_UP:
            selected = (selected - 1) % len(files)
        elif key == curses.KEY_DOWN:
            selected = (selected + 1) % len(files)
        elif key == ord("\n"):
            return os.path.join(path, files[selected] + ".py")

def file_selection(filepath):
    try:
        subprocess.run(["python3", filepath])
    except Exception as e:
        print(f"Failed to boot file: {e}")
        input("Press Enter to return...")

if __name__ == "__main__":
    selected_file = curses.wrapper(main)
    if selected_file:
        file_selection(selected_file)
