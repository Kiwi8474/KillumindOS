import os
import shutil
import time
import pickle
import random
import re
from collections import Counter
if os.name == "nt":
    try:
        import curses
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "windows-curses"])
        import curses
else:
    import curses

if os.name == "nt":
    os.system("chcp 65001 >nul")

# clear console
def clear():
    os.system("cls" if os.name == "nt" else "clear")


# terminal
def terminal(userFiles):
    while True:
        userInput = input(f"{os.path.dirname(os.path.abspath(__file__))} > ").lower()

        if userInput == "exit":
            break

        elif userInput == "ls":
                try:
                    files = os.listdir(userFiles)
                    if not files:
                        print("This folder is empty")
                    else:
                        for file in files:
                            print(f"- {file}")
                except FileNotFoundError:
                    print("Folder not found")
                except Exception as e:
                    print(f"[ERROR]: {e}")
        else:
            print(f"command '{userInput}' not found")


# file manager
def file_manager(userFiles):
    currentFolder = userFiles

    if not os.path.exists(currentFolder):
        os.makedirs(currentFolder)

    while True:
        clear()
        print("===== File Manager =====")
        files = os.listdir(currentFolder)

        if files:
            print(f"\nCurrent folder: {currentFolder}\n")
            for file in files:
                print(file)
        else:
            print(f"\nCurrent folder: {currentFolder}\n")
            print("No files in this folder")
        userInput = input("\n> ").lower()

        if userInput == "exit":
            break

        elif userInput == "create file":
            fileName = input("File name: ")
            with open(os.path.join(currentFolder, fileName), "w") as f:
                f.write("")

        elif userInput == "create folder":
            folderName = input("Folder name: ")
            os.makedirs(os.path.join(currentFolder, folderName), exist_ok=True)

        elif userInput == "enter":
            folderName = input("Folder to enter: ")
            newPath = os.path.join(currentFolder, folderName)
            if os.path.isdir(newPath):
                currentFolder = newPath
            else:
                print(f"Folder '{folderName}' not found.")
                time.sleep(1)
        
        elif userInput == "delete":
            fileToDelete = input("File to delete: ").strip()
            if not fileToDelete:
                print("No file name entered.")
                time.sleep(1)
                continue

            deletePath = os.path.join(currentFolder, fileToDelete)

            if os.path.isfile(deletePath):
                os.remove(deletePath)
                print(f"File '{fileToDelete}' deleted.")
            elif os.path.isdir(deletePath):
                shutil.rmtree(deletePath)
                print(f"Folder '{fileToDelete}' deleted.")
            else:
                print(f"File or folder '{fileToDelete}' not found.")
            time.sleep(1)

        elif userInput == "back":
            parent = os.path.dirname(currentFolder)
            if os.path.exists(parent) and parent.startswith(userFiles):
                currentFolder = parent
            else:
                print("You are already in the main folder")
                time.sleep(1)
        
        elif userInput == "edit":
            fileToEdit = input("File to edit: ")
            if os.path.isfile(os.path.join(currentFolder, fileToEdit)):
                text_editor(os.path.join(currentFolder, fileToEdit))
            else:
                print(f"File '{fileToEdit}' not found or is not a file")
                time.sleep(1)


# text editor
def text_editor(fileToEdit):
    while True:
        clear()
        print("\n===== Text Editor =====")
        print(f"Current file: {fileToEdit}\n")

        if os.path.isfile(fileToEdit):
            with open(fileToEdit, "r") as f:
                content = f.read()
        else:
            content = "[File not found]"

        print("--- File Content ---")
        print(content if content else "[Empty file]")
        print("--------------------\n")

        userInput = input("> ").lower()

        if userInput == "write":
            newText = input("Text to append: ")
            with open(fileToEdit, "a") as f:
                f.write(newText + "\n")

        elif userInput == "clear":
            confirm = input("Are you sure? (yes/no): ")
            if confirm.lower() == "yes":
                with open(fileToEdit, "w") as f:
                    f.write("")

        elif userInput == "exit":
            break

        else:
            print("Unknown command.")
            time.sleep(1)


# wallpapers
wallpapers = {
    "killua1": [
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠀⠀⠀⠀⢤⡀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣶⠖⠈⠀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣆⠀⠀⠀⣸⣿⣷⡀⠀⠀⢀⢴⣿⣿⣿⣿⣿⣿⣀⣀⣠⣶⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣦⡀⣸⣿⣿⣿⣿⣀⣴⣟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠸⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣬⣿⣿⣿⣿⣿⣿⣿⣟⣾⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻⣿⣿⡿⡿⣛⣯⣭⣭⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⣄⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣻⣿⣿⣛⡿⣿⣿⣟⢟⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣤⣤⣤⣤⣤⣤⣤⠆",
"⢀⡀⠀⠀⠀⠀⠀⠀⠘⠿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣟⣛⣿⣛⣻⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠀",
"⠈⢿⣿⣶⣶⣦⣤⣤⣴⣶⣾⣿⣿⣿⣿⣿⣿⣿⡿⣷⢟⣯⣶⣿⣿⣿⣿⣿⢯⡿⣿⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀",
"⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡿⣫⣷⣻⣿⣵⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣮⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣀⣀⠀⠀⠀",
"⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣳⣿⣿⣿⣽⡿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣻⢿⣾⣿⣿⣿⣿⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣏⠙⠋⠉⠉⠀⠀",
"⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⡿⣻⣿⣻⣿⣿⣿⣿⢿⣿⢽⣿⣏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣽⣿⣿⣿⣷⡻⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀",
"⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⡟⡿⣽⣿⣿⣿⢳⣿⣿⣿⣿⣿⣿⡿⣾⣿⣿⣻⣿⣽⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀",
"⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣹⢳⣿⣹⣿⡿⣿⣿⣾⣿⣿⣿⣿⡇⣿⣿⣿⣷⣽⣿⣟⣿⡇⣿⣿⣧⣿⣷⢿⣿⣿⡾⣿⣿⡿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀",
"⢀⡾⠟⠉⢀⣴⡿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣷⣿⡟⣿⣿⡿⣿⣿⡇⣿⣧⣿⣿⣿⣿⣾⣞⣣⣿⣿⣿⣸⣿⣾⣿⣿⣷⣿⣿⣇⣿⣽⣿⣿⣿⣿⣿⡉⠙⠛⠛⠋⠀⠀",
"⠈⠀⠀⢠⠞⢁⣼⣿⣿⣿⣸⡇⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣽⣿⠃⣿⣿⣿⣿⣿⣿⣿⣿⣿⡹⣿⣿⡏⣿⡏⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀",
"⠀⠀⠀⣀⣴⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣅⣻⠿⢿⣿⣿⡿⣿⢠⣿⣿⣿⣿⣿⣿⡇⣿⣿⢻⣻⣿⡇⡟⣷⣿⡻⣿⢻⣿⡟⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀",
"⠀⠐⢾⣿⣿⣿⣿⣿⣿⣿⣿⡧⣿⣿⢹⣿⣿⣽⣿⣼⣝⡻⢧⣿⢸⣹⣿⡸⣿⣿⣿⡇⣽⣿⣼⣷⣿⡿⢟⣫⣴⡾⣏⣸⣿⢷⣿⣿⣿⣿⣿⣏⢻⣿⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠈⠉⠙⠛⠛⣻⣿⣹⡏⣾⣿⣼⣿⠿⠷⠽⠿⠿⠿⣶⣌⠸⣷⢿⣿⣻⣿⣿⡇⣿⣻⣏⢟⣥⠶⠿⠃⠛⠛⠸⢿⡿⣼⣷⣿⣿⣿⣿⠹⡄⠹⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣧⢇⣿⡽⣿⡹⡇⢠⣾⣿⢷⠄⠀⠈⠘⢮⡻⡻⢯⣻⣿⣿⣿⣧⣳⢛⣉⠀⠀⠈⢻⣷⢀⡾⢻⡏⣾⣿⣿⣿⣿⣇⠀⠀⠙⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⣠⣿⡿⠟⣿⣠⣿⣿⣽⣏⣇⣧⡻⣿⢻⣦⣄⣴⢢⣷⣽⣿⣾⣷⡻⣿⣹⣟⣵⣇⣭⣤⣴⡾⣸⢏⡾⣰⡿⣿⣿⣿⡟⢿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠐⠉⠁⠀⠀⢹⣯⡻⣾⣿⣿⣿⣿⣿⣿⣷⡩⠯⠥⣟⣻⣿⣿⣿⣿⣿⣾⡿⣿⣿⣿⠶⠭⢝⣚⣿⣿⣿⣸⢟⣽⣳⣿⡇⠀⠈⠉⠛⠛⠂⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⠊⠉⢿⣾⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣵⢟⣵⢹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⢷⣯⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢷⡄⣿⠃⠀⠻⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⢿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣫⠻⠃⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠋⢻⡽⢿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠸⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠃⠀⠉⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢸⣾⣽⡻⣿⣿⣿⣿⣿⣿⣻⡗⠀⠀⠀⠀⠀⣸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣼⣿⠒⢄⠀⠀⠈⠛⠿⣿⣷⣯⣛⣻⣿⣿⣿⠃⠀⠀⠀⡠⣴⣿⣿⣿⣿⣷⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣾⣿⣿⣟⠀⠀⠑⢄⠀⠀⠀⠀⠉⠙⠛⠛⠛⠉⠀⠀⠀⡠⠁⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠈⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠊⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠁⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀⠀",
],
    "killua2": [
"⠛⠛⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⢫⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛",
"⠀⠀⠀⣿⣿⣿⣿⣿⣿⡿⢟⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣥⣦⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀",
"⣿⣿⣿⣿⣿⣿⣿⣟⣁⣶⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣉⣿⣿⣿⣿⣿⣿⣿⣶",
"⣿⣿⣿⣿⣿⣿⣿⣿⠿⣋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿",
"⡙⠿⠿⠿⠿⠟⣋⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠯⠻⠿⣿⣿⣿⠿⣫⣥⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⡙⠻⣿⣿⣿⣿",
"⣿⣄⡒⢶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣫⣤⣶⣿⡿⠛⣫⣥⣾⣿⣿⣽⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣌⠻⢿⣿",
"⠉⠉⠉⢠⣍⡛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢟⣩⡟⠁⢚⣩⣵⣶⢂⣶⣿⣿⡿⢿⣿⣿⣷⣬⣙⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣍",
"⣾⣿⣷⢼⣿⣿⣿⣶⠖⣈⣼⣿⣿⣿⣿⣿⡿⢋⣴⣿⡟⣠⣾⣿⣿⣿⣿⣌⢻⣿⣿⣌⠢⣙⣛⠿⠿⠿⠿⠿⠶⠖⣛⣉⣥⣶⣿⣿⣷⣦⣙⢿⣿⣿⣿⣿⣿⣿⣿⠿⡿⠿⠿⠛⢁",
"⣿⣿⣿⢸⣿⣿⠟⣡⡾⠿⠟⣿⣿⣿⣿⠟⣤⣿⣿⠟⣠⣿⠟⣿⣿⣿⣿⣿⡷⣬⡛⠿⢷⣬⣙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⠻⣿⣿⣿⣧⡙⢿⣿⣿⣿⣿⣿⣷⣄⡙⢿⡆⣾",
"⣿⣿⣿⢸⠟⠁⠨⠥⠖⣠⣾⣿⣿⣿⢋⣾⣿⣿⢋⣼⡿⢃⣾⣿⢋⣿⣿⠟⣴⣿⣿⣷⣶⣮⣭⣥⣬⣭⣹⣏⠻⣿⣿⣏⠻⣿⣿⣷⡌⢿⣿⣿⣿⡌⢿⣿⣿⣿⣿⠛⠛⠿⣌⠳⣿",
"⢿⣿⡇⢸⣿⣿⣿⠏⣼⣿⣿⣿⣿⠇⣾⣿⣿⢃⣾⡟⣱⣿⣿⢃⣾⣿⠏⣼⡿⢹⣿⣿⣿⢹⣿⣿⢿⣿⣿⣿⣷⡙⢿⣿⣷⡙⣿⣿⣿⣎⠻⣿⣿⣷⡘⣿⣿⣿⣿⣷⡜⢷⣮⡀⢽",
"⠈⠉⠁⢸⡿⠟⣡⣾⣿⣿⣿⣿⠟⢸⣿⡿⠃⣾⡿⢱⣿⡿⠃⣾⡿⠃⢸⣿⠃⣼⣿⣿⠏⠘⣿⣿⠀⠙⢿⣿⣿⣷⠀⢉⢿⣿⡜⢿⣿⣿⡄⠈⢻⣿⣇⢿⣿⣿⣿⣿⣷⡌⢿⡇⠀",
"⠀⠀⠐⠲⢶⣿⣿⣿⣿⣿⣿⣿⠇⣿⣿⠃⢰⣿⠇⣿⡿⠁⢀⣿⡃⠀⣿⣇⠀⢿⣿⣿⠀⠀⠻⣿⡄⢸⣆⠙⣿⣿⡇⠀⠂⠻⣷⡀⢻⣿⣿⠀⠀⢻⣿⠘⢷⡘⡻⣿⣿⣿⣦⡀⠄",
"⠀⠀⠀⢸⣶⣤⣬⣭⠭⢉⣤⠟⠀⣿⠏⢀⢸⡏⠀⣿⢣⠃⡜⣿⠇⡄⣿⣿⠁⢸⣿⡏⣶⡆⠀⠻⣇⠀⢋⡤⠈⢿⣗⠠⣄⠀⢻⡇⠀⢻⣿⠀⣶⡀⣿⠀⠈⣷⡈⠢⠬⠙⠻⠿⠂",
"⠀⠀⠀⢈⣥⣬⣭⣍⠁⣼⠃⠀⡀⢿⠀⣼⢸⢃⠀⣿⡟⠀⠁⠟⠀⠑⢸⣿⢀⡎⢻⡇⣿⠁⢠⡄⠑⢤⠀⣴⣶⠄⠛⠰⠺⠆⢾⡇⡀⠈⣿⠀⣉⠁⠈⢀⠈⣼⣇⢀⣀⣀⣐⡂⠀",
"⠀⢠⡄⢸⣿⣿⣿⣿⠀⠋⡔⢸⣿⠸⠀⣛⠀⣿⠀⠀⠀⠀⠀⠀⢀⡀⠀⠁⠀⠙⢆⠻⣿⣇⠈⠄⣿⡦⠁⠀⠀⠁⡈⢀⠁⠀⠸⡇⠃⠸⢹⠐⠛⢣⠀⣿⡇⠘⢻⠈⣿⣿⣿⡇⠀",
"⠴⠿⠇⢸⣿⣿⣿⣿⣀⣾⡇⢸⣿⣧⢸⠟⠃⠙⠀⣦⠀⣴⣾⣿⣿⣛⠉⠂⣴⡈⢺⣷⡙⢿⣆⠃⢸⡁⠀⣀⡐⠛⢷⣿⣷⣦⡄⢀⡴⠀⠃⠘⣏⣼⠐⣿⡇⡀⠀⢠⣿⣿⣿⡇⠀",
"⠀⠀⠀⢸⣿⣿⣿⣿⣿⡟⣠⣿⣿⠇⣼⢨⠉⡀⠀⢸⣷⣿⣿⣿⠛⠿⠁⠀⠸⣿⣴⣿⣿⣶⣌⡀⢊⣴⡟⠻⠟⠀⠀⢹⣿⣿⣃⣾⠇⠀⣼⡇⣿⡿⢀⣿⡇⣷⣴⣿⣿⣿⣿⡇⠀",
"⠀⠀⡀⢸⡟⢿⠿⠿⠃⠐⠛⠉⢭⠄⠹⣿⡄⠻⣄⡈⣿⣿⣧⡙⠄⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⡼⢟⣿⣿⡿⠀⠼⢋⣴⠿⠁⢘⠛⠧⢸⣿⣿⣿⣿⣿⣷⣿",
"⠄⠀⠃⠀⠻⠀⠀⢠⣶⡶⠶⣦⠤⠾⠧⠈⠛⢷⣤⣁⠸⣿⣿⣿⣶⣤⣤⣶⣾⣿⣿⣿⠉⣿⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣿⣿⣿⡇⣶⣶⠟⠁⠀⢠⠀⠀⠀⢀⣤⣤⣭⣭⣽⣏⣿",
"⠀⠁⠀⢠⡄⠘⠀⠀⢍⢛⠀⠈⠁⠀⠀⣶⠀⠀⣙⠛⠃⠀⣶⣶⢸⣿⣿⣿⣿⣿⣿⡄⠰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢁⡍⠁⢰⣿⣶⡌⠁⠀⠀⠸⢿⣿⣿⣿⣿⣿⣿",
"⠀⠉⠁⠈⢀⣄⡀⠈⠀⠴⠧⣼⠆⠀⠀⠁⠀⠀⠈⢀⣶⠀⢿⣿⡎⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢋⡉⢿⡿⢃⠀⠁⠀⢠⣦⡀⠁⢸⣿⣶⣷⣦⣿⣿⠛⣿⣿⣿",
"⠀⣦⡤⠀⠀⡉⠁⢄⠀⠀⠀⢀⡄⠀⠀⢠⣤⡀⢀⣈⠀⠀⠈⠛⢿⠆⣻⣿⣿⣿⣿⣟⡛⠿⣿⣿⣿⣿⣿⣿⣧⠸⡿⠟⠀⢠⠏⢠⠒⢠⣄⠃⠀⢀⣈⡁⢬⠟⢻⣿⣷⠶⢿⡇⠀",
"⠤⠀⠀⠘⠆⢿⠀⠀⠀⠀⠀⠈⠁⣄⡀⠈⠅⠀⠀⠰⡶⢀⣄⢤⠀⠈⠛⢿⣿⣿⣿⣿⣛⢳⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⣶⡆⠠⣄⣀⠀⠻⠯⠃⠀⠐⠏⣿⣿⠿⣿⡿⠲",
"⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⢀⣉⠀⠀⢀⣤⣤⣤⣴⣿⡏⠘⠀⠀⠂⠀⠈⠙⠻⢿⣿⣿⣿⣿⡿⠛⣩⣴⣶⡀⠀⠸⠁⠂⠀⡏⣿⣧⡈⠛⠓⠀⠀⠀⣴⣤⠾⣤⠛⣶⣷⣷⣴",
"⠀⠀⠀⠈⢿⠟⠀⠀⠀⠀⠀⠀⠉⠋⠀⠀⣾⣿⣿⣿⣿⣿⣷⠸⣆⠀⠀⠀⣶⣧⣹⣶⣬⣉⣉⣡⣶⣿⣿⣿⣿⣿⠃⠀⠀⠀⡀⢠⣿⣿⣿⣶⣾⣿⣷⣦⡈⣡⣄⢸⡿⣿⣿⡿⣏",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⣡⣶⣿⣿⣇⠹⣿⣿⣿⣿⣿⣿⡆⢻⣦⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⡤⠂⢀⡴⢡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠻⠤⣉⣿⣿⣍⣙",
"⢀⠀⣈⣁⠐⢦⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣆⠻⣿⣿⣿⣿⣿⣿⡄⢿⣦⡀⠘⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⡔⠂⢀⣴⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⡿⠛⣡⣴⣶⣤⡁⠈⠛⣿⣿",
"⣾⠉⠀⠉⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣦⡙⢿⣄⠀⠀⢉⠻⣿⣿⣿⠟⡁⠀⠀⣠⠶⠛⣡⣴⣿⣿⣿⣿⣟⣻⡿⠟⣩⣴⣿⣿⣿⣿⣿⣿⣦⠀⠹⠳",
"⠉⠀⠀⠀⠀⣴⣿⣿⣿⣿⡇⠘⣿⣿⣿⣿⣿⣿⡿⠦⠙⠻⣿⣿⣿⣿⣿⣶⣤⣅⡀⠘⠓⠄⠉⠥⡺⠁⣀⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⡟⢋⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀",
"⣀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣇⠀⢻⡻⠸⠿⢋⣡⣶⣾⣶⣶⣶⣶⣬⡙⠻⢿⡿⠿⣿⣆⠹⣿⣿⡟⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢉⣴⣿⣿⣿⣿⣿⣿⣿⠙⣿⣿⣿⣿⣿⡇⠀",
"⣉⣀⣴⣿⣿⣿⣿⣿⣿⣿⠛⣠⣶⣦⣀⠿⣿⣿⣿⠿⠿⠿⠿⠿⠿⣿⣷⣦⣄⠀⣀⡙⠇⢹⣿⢣⡿⠛⠉⠼⠛⠛⠛⣛⣛⣉⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⣿⣿⣿⣿⣿⣧⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⠛⢁⣬⣿⣿⣿⣿⣷⣌⡉⠀⣠⢤⢴⡦⠠⣬⣄⣈⡉⠤⢾⡿⢿⡶⢠⠀⢤⣤⠶⠀⠀⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢀⣿⣿⣿⣿⣿⣿⠀",
],
    "killua3": [
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣛⠛⢭⣭⣽⣛⡛⠛⠿⣿⣿⣿⣿⣿⢉⡙⢿⣿⡛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣙⠛⠒⠮⠙⢿⣿⣿⣿⣶⣮⣍⡛⢿⡇⣿⣦⡙⣧⢱⡘⣿⣿⣿⣿⢏⣴⢸⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡍⢉⣉⣉⣉⣉⣉⣉⣁⣙⠳⣶⣦⣽⣿⣿⣿⣿⣿⣿⣶⡅⢻⣿⣷⡈⢸⣷⠘⣿⠟⣡⣿⣿⢸⣿⡏⣉⣿⣽⠘⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⣿⡆⣱⣾⣿⣿⠇⠼⢛⣡⣤⣤⣤⣤⠤⠈⢹⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⢃⣙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⠏⣠⣾⣿⣿⣿⣿⡿⢁⣰⣻⣥⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣩⣵⣶⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⡟⠠⢤⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠏⡥⡾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣿⣿⡟⠀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⠶⠷⢒⣀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣿⣿⣿⡇⡄⣿⣿⣿⠋⣿⣿⣿⣿⣿⣏⣁⣀⠀⠆⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣀⠲⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⢄⣒⣛⣛⢦⠻⠛⡱⢃⡿⢟⡁⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣷⣮⣝⡛⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⣴⣾⣿⣿⣿⣿⣦⡐⣤⡐⢒⣒⣩⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⡿⠟⣛⣥⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡌⣷⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣴⣶⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⠀⢰⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⣿⠀⣿⣿⣿⣿⣟⠻⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣷⣌⠻⣷⣿⣿⣿⣿⣷⣾⣷⣶⢖⣨⣾⡿⠟⢩⣿⡿⠋⣼⣿⢿⣿⣿⣿⢃⣿⣿⠟⣿⣿⣿⢹⣿⣿⢏⣼⠟⣴⢿⣿⡿⣿⡏⢿⣦⡙⢿⣿⣿⣿⣿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣷⣬⡛⢿⣿⣿⣿⣿⣿⣯⣛⣭⣴⡾⣳⡿⢋⠀⣾⠟⣡⣿⣿⠿⠁⣾⣿⣿⠀⣿⣿⡇⠘⠋⢕⣛⣥⣾⣿⠈⢿⣧⠘⣿⣆⠻⣿⣮⠻⣍⡊⢡⣴⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⢂⣭⣿⣿⣿⣿⣿⣿⣿⣿⣣⢏⣴⠟⣼⣧⡆⣿⣿⢏⠀⣼⣿⣿⠏⢀⣿⣿⠣⢰⣶⠘⣿⣿⣿⣿⣶⠘⣿⡆⢿⣿⡄⠝⢿⣧⠹⣿⣎⢻⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⡿⠵⠾⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣾⡿⣿⣿⣿⡡⠁⣸⣿⣿⠏⡖⢸⣿⣏⡄⡆⣿⡇⢻⡿⣿⣿⣿⡇⢻⣧⠸⣿⣿⢸⣆⢻⣇⢉⠻⡄⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠟⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⡏⣸⣿⢃⣿⣿⠗⣠⢡⣿⡿⢫⡞⠀⣾⣿⡿⢡⡇⢸⡟⠀⣿⣿⠿⡿⢁⠸⣿⠀⢹⣿⡈⣿⣆⢻⠘⣷⡁⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢰⣿⣿⢸⣿⡟⣰⡇⣸⣿⡿⢂⡈⠐⠿⠿⠣⢞⠁⣉⠁⡇⣻⣯⡙⢁⣈⡄⡟⣸⡇⣿⢇⣿⣿⡆⡇⣹⣿⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣀⣙⣛⣛⡻⠿⣿⣿⣿⣿⣿⡿⢃⣤⣤⡋⢸⣿⢱⣿⢱⣿⠟⣡⣿⢣⣿⠏⢴⣿⠛⣼⢃⣾⡇⣿⡿⢃⣾⠿⠃⠡⢿⠆⠸⢸⣿⣿⣧⢰⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣙⠻⣿⣿⢡⣴⣦⣌⠻⢸⣿⢸⣿⢈⡕⠚⡉⠀⢊⣀⡒⠶⠌⠀⣵⡿⢉⠀⢟⣵⣯⠕⢈⢀⣶⣿⢸⠀⠙⢿⣿⣿⠘⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡐⢤⣶⣶⣿⣿⢸⣿⣿⣿⠀⣧⠻⢸⣿⣿⣿⢙⠁⠴⢿⣿⣿⣷⣤⣼⡟⣱⣿⣴⣿⣿⣯⣾⣿⣿⣿⣿⢸⣿⡐⠲⣬⣉⡁⣹⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣬⣙⠻⠿⢆⠻⣝⢿⣧⡙⣃⡈⣿⣿⣿⣿⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⠈⡻⠧⠈⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⢼⡗⠌⠛⢦⣼⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣿⡿⣿⣿⣿⡿⠈⣿⣦⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⢡⣿⣦⠀⢀⠀⠹⣿⣿⣿⣿⣿⣿⡏⣶⣮⣭⣟⣛⣛⣛⣛⣻⣭⣭⡥⡂⣸⣿⡿⢁⣤⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⡆⠘⣽⡆⠈⠻⣿⣿⣿⣿⡇⢍⢫⣭⣽⣿⣿⣿⣿⠿⠛⣫⣭⣶⡿⢋⣰⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢡⡄⠙⣿⣆⠑⢌⡛⠿⣿⣿⣦⣭⣉⣉⣭⣭⣶⣶⣿⣿⣿⠟⢋⣴⣿⣿⣿⣿⣿⣿⡀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⣋⣡⣶⣶⠹⣿⣄⠙⠿⣷⣄⡙⠻⢶⣭⣙⡻⠿⠿⣿⣿⣿⣿⣿⠟⢁⣐⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣛⣡⣴⣿⣿⣿⣿⣿⣦⡘⢿⣧⣷⣿⣿⣿⣷⣤⠤⣬⣍⣉⠋⠀⢠⣤⣤⠄⣰⣿⣿⣿⣿⣶⣤⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠋⣡⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡙⢿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣷⣿⣿⡟⢡⣶⣿⣿⣿⣿⣿⣿⣿⣷⡈⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⠿⠿⠿⠿⠿⠿⠿⠃⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠦⠹⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠀⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠹⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀",
],
}


# settings
def settings(userFiles):
    current_wallpaper = None
    while True:
        clear()
        print("===== Settings Manager =====\n")
        print("Wallpaper")

        userInput = input("\n> ").lower()

        if userInput == "exit":
            break
        
        elif userInput == "wallpaper":
            while True:
                clear()
                print("===== Wallpapers =====\n")
                print("Killua1")
                print("Killua2")
                print("Killua3")
                wallpaperInput = input("\nChoose a Wallpaper: ").lower()
            
                if wallpaperInput == "killua1":
                    wallpaper = "killua1"
                    break
                elif wallpaperInput == "killua2":
                    wallpaper = "killua2"
                    break
                elif wallpaperInput == "killua3":
                    wallpaper = "killua3"
                    break
                else:
                    print("Invalid input")
                    time.sleep(1)

            print(f"Wallpaper set to {wallpaper}")
            time.sleep(1)

            wallpapersFolder = os.path.join(userFiles, "wallpapers")
            os.makedirs(wallpapersFolder, exist_ok=True)
            with open(os.path.join(wallpapersFolder, "wallpaper_auswahl.pkl"), "wb") as file:
                pickle.dump(wallpaper, file)
            print(f"Wallpaper '{wallpaper}' saved")
            time.sleep(1)


# minesweeper
def generate_minesweeper_field(rows, cols, num_mines):
    field = [["0" for _ in range(cols)] for _ in range(rows)]
    mines = set()
    while len(mines) < num_mines:
        r = random.randint(0, rows - 1)
        c = random.randint(0, cols - 1)
        if (r, c) not in mines:
            mines.add((r, c))
            field[r][c] = "X"
    for r in range(rows):
        for c in range(cols):
            if field[r][c] == "X":
                continue
            count = 0
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols and field[nr][nc] == "X":
                        count += 1
            field[r][c] = "·" if count == 0 else str(count)
    return field

def print_field(field, revealed, flagged):
    cols = len(field[0])
    header = "  " + "".join(f"{i:2}" for i in range(cols))
    print(header)
    
    for r in range(len(field)):
        row = f"{r:2} "
        for c in range(len(field[r])):
            if flagged[r][c]:
                row += "⚐ "
            elif revealed[r][c]:
                row += field[r][c] + " "
            else:
                row += "■ "
        print(row)

def reveal(field, revealed, r, c):
    if revealed[r][c] or field[r][c] == "X":
        return
    revealed[r][c] = True
    if field[r][c] == "·":
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < len(field) and 0 <= nc < len(field[0]) and not revealed[nr][nc]:
                    reveal(field, revealed, nr, nc)

def auto_reveal_if_flags_match(field, revealed, flagged, r, c):
    if not revealed[r][c]:
        return
    if not field[r][c].isdigit():
        return
    target_number = int(field[r][c])
    flag_count = 0
    hidden_neighbors = []
    
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < len(field) and 0 <= nc < len(field[0]):
                if flagged[nr][nc]:
                    flag_count += 1
                elif not revealed[nr][nc]:
                    hidden_neighbors.append((nr, nc))

    if flag_count == target_number:
        for nr, nc in hidden_neighbors:
            if field[nr][nc] == "X":
                revealed[nr][nc] = True
                clear()
                print_field(field, revealed, flagged)
                print("You hit a mine!")
                input("Press enter to exit ")
                exit()
            else:
                reveal(field, revealed, nr, nc)

def reveal_all_mines(field, revealed):
    for r in range(len(field)):
        for c in range(len(field[r])):
            if field[r][c] == "X":
                revealed[r][c] = True

def minesweeper():
    while True:
        clear()
        print("===== Minesweeper =====\n")
        rows = input("Enter number of rows: ")

        if not rows.isdigit():
            print("Can only contain numbers!")
            time.sleep(1)
            continue

        rows = int(rows)
        if rows >= 11:
            rows = 10
        break

    while True:
        clear()
        print("===== Minesweeper =====\n")
        cols = input("Enter number of columns: ")
    
        if not cols.isdigit():
            print("Can only contain numbers!")
            time.sleep(1)
            continue

        cols = int(cols)
        if cols >= 11:
            cols = 10
        break

    while True:
        clear()
        print("===== Minesweeper =====\n")
        mines = input("Enter number of mines: ")

        if not mines.isdigit():
            print("Can only contain numbers!")
            time.sleep(1)
            continue

        mines = int(mines)
        if mines >= rows * cols:
            print("Too many mines!")
            time.sleep(1)
            continue
        break

    field = generate_minesweeper_field(rows, cols, mines)
    revealed = [[False for _ in range(cols)] for _ in range(rows)]
    flagged = [[False for _ in range(cols)] for _ in range(rows)]
    
    while True:
        clear()
        print("===== Minesweeper =====\n")
        print_field(field, revealed, flagged)
        
        try:
            action, row, col = input("Enter action (r)eveal, (f)lag or (a)uto reveal with coords: ").lower().split()
            row, col = int(row), int(col)
            
            if 0 <= row < rows and 0 <= col < cols:
                if action.lower() == "f":
                    if not revealed[row][col]:
                        flagged[row][col] = not flagged[row][col]
                    else:
                        print("You cannot flag a revealed tile.")
                        time.sleep(1)
                elif action.lower() == "r":
                    if flagged[row][col]:
                        flagged[row][col] = False
                    if field[row][col] == "X":
                        revealed[row][col] = True
                        clear()
                        print_field(field, revealed, flagged)
                        print("You hit a mine!")
                        reveal_all_mines(field, revealed)
                        print_field(field, revealed, flagged)
                        input("Press enter to exit ")
                        break
                    else:
                        reveal(field, revealed, row, col)
                elif action.lower() == "a":
                    auto_reveal_if_flags_match(field, revealed, flagged, row, col)
            else:
                print("Invalid input")
                time.sleep(0.5)
        except ValueError:
            print("Invalid input")
            time.sleep(0.5)
        
        if all((revealed[r][c] or field[r][c] == "X" or flagged[r][c]) for r in range(rows) for c in range(cols)):
            clear()
            print_field(field, revealed, flagged)
            print("You won!")
            input("Press enter to exit ")
            break


# snake
def snake(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.clear()
    stdscr.refresh()

    height, width = 20, 40
    win = curses.newwin(height, width, 0, 0)
    win.keypad(True)
    win.timeout(100)

    snake = [[height//2, width//2 + i] for i in range(3)][::-1]
    direction = (0, 1)
    key_map = {
        curses.KEY_UP:    (-1, 0),
        curses.KEY_DOWN:  (1, 0),
        curses.KEY_LEFT:  (0, -1),
        curses.KEY_RIGHT: (0, 1)
    }

    food = [random.randint(1, height-2), random.randint(1, width-2)]
    while food in snake:
        food = [random.randint(1, height-2), random.randint(1, width-2)]
    win.addch(food[0], food[1], "●")

    score = 0

    while True:
        win.border()
        win.addstr(0, 2, f" Score: {score} ")

        for y, x in snake:
            win.addch(y, x, "■")

        key = win.getch()
        if key in key_map:
            new_dir = key_map[key]
            if (new_dir[0] != -direction[0]) or (new_dir[1] != -direction[1]):
                direction = new_dir

        new_head = [snake[0][0] + direction[0], snake[0][1] + direction[1]]

        if (
            new_head[0] in [0, height-1]
            or new_head[1] in [0, width-1]
            or new_head in snake
        ):
            break

        snake.insert(0, new_head)

        if new_head == food:
            score += 1
            food = [random.randint(1, height-2), random.randint(1, width-2)]
            while food in snake:
                food = [random.randint(1, height-2), random.randint(1, width-2)]
            win.addch(food[0], food[1], "●")
        else:
            tail = snake.pop()
            win.addch(tail[0], tail[1], " ")
    while True:
        win.clear()
        win.border()
        win.addstr(height//2 - 1, width//2 - 5, "GAME OVER")
        win.addstr(height//2, width//2 - 4, f"Score: {score}")
        win.addstr(height//2 + 2, width//2 - 11, "Press Enter to exit ")
        win.refresh()
        win.nodelay(False)
        key = win.getch()
        if key == ord("\n"):
            break


    score = len(snake)
    return score


# calculator
def calculator():
    while True:
        clear()
        print("===== Calculator =====")
        operation = input("Enter equation: ")

        if operation.lower() == "exit":
            break

        try:
            number1, operator, number2 = operation.split()
            number1, number2 = float(number1), float(number2)

            if operator == '+':
                result = number1 + number2
            elif operator == '-':
                result = number1 - number2
            elif operator == '*':
                result = number1 * number2
            elif operator == '/':
                if number2 == 0:
                    print("Cannot divide by zero!")
                    continue
                result = number1 / number2
            else:
                print("Invalid operator. Use one of these: +, -, *, /")
                continue

            print(f"Result: {result}")
            input("Press enter to continue ")
        except ValueError:
            print("Invalid input")


# casino
def casino(users, userFiles):
    currentUser = os.path.abspath(os.path.join(userFiles, ".."))
    userFile = os.path.abspath(os.path.join(currentUser, f"{os.path.basename(currentUser)}Money.txt"))
    with open(userFile, "r") as f:
        content = f.read()
    match = re.search(r"\d+", content)
    if match:
        value = int(match.group(0))
    else:
        print("No value found")
        return
    
    money = value


    def blackjack():
            nonlocal money
            userCards = []
            dealerCards = []
            userPass = False
            dealerPass = False

            def hit():
                userCard = random.randint(1, 11)
                userCards.append(userCard)

            def hit_dealer():
                dealerCard = random.randint(1, 11)
                dealerCards.append(dealerCard)

            while True:
                clear()
                print("===== Blackjack =====")
                print(f"Money: {money}")
                userBet = input("Place bet: ")

                if not userBet.isdigit():
                    print("Invalid input")
                    time.sleep(1)
                else:
                    userBet = int(userBet)
                    if userBet > money:
                        print("Not enough money!")
                        time.sleep(1)
                    else:
                        break

            userCards.append(random.randint(2,21))
            dealerCards.append(random.randint(2,21))

            while True:
                if not userPass or not dealerPass:
                    clear()
                    print("===== Blackjack =====\n")
                    print(f"Bets: {userBet * 2}\n")
                    print(f"You: {sum(userCards)}")
                    print(f"Dealer: {sum(dealerCards)}")
                    userInput = input("\nEnter (h)it or (p)ass: ").lower()
                    print("Dealer thinking...")
                    time.sleep(1)
                    if userInput == "h":
                        hit()
                        if sum(dealerCards) < 22 and sum(dealerCards) < sum(userCards) and sum(userCards) < 22:
                            hit_dealer()
                            dealerPass = False
                        else:
                            dealerPass = True
                    elif userInput == "p":
                        userPass = True
                        if sum(dealerCards) < 22 and sum(dealerCards) < sum(userCards) and sum(userCards) < 22:
                            hit_dealer()
                            dealerPass = False
                        else:
                            dealerPass = True
                        time.sleep(1)
                    else:
                        print("Invalid input")
                        time.sleep(1)
                else:
                        break

            clear()
            print("===== Results =====\n")
            if sum(userCards) > 21:
                print("You busted. You lost!\n")
                print(f"-{userBet} Money")
                money -= userBet
                print(f"Money: {money}")
            elif sum(dealerCards) > 21:
                print("Dealer busted. You won!\n")
                print(f"+{userBet * 2} Money")
                money += userBet
                print(f"Money: {money}")
            elif sum(userCards) > sum(dealerCards):
                print("You won!\n")
                print(f"+{userBet * 2} Money")
                money += userBet
                print(f"Money: {money}")
            elif sum(userCards) < sum(dealerCards):
                print("You lost!\n")
                print(f"-{userBet} Money")
                money -= userBet
                print(f"Money: {money}")
            elif sum(userCards) > 21 and sum(dealerCards) > 21:
                if sum(userCards) < sum(dealerCards):
                    print("Both busted, but you're closer to 21. You won!\n")
                    money += userBet
                    print(f"Money: {money}")
                elif sum(userCards) > sum(dealerCards):
                    print("Both busted, but dealer is closer to 21. You lost!\n")
                    money -= userBet
                    print(f"Money: {money}")
                else:
                    print("Both busted equally. It's a tie!\n")
                    print("+0.0 Money")
                    print(f"Money: {money}")
            else:
                print("It's a tie!\n")
                print("+0.0 Money")
                print(f"Money: {money}")


            with open(userFile, "w") as f:
                f.write(f"Money: {money}")

            time.sleep(3)


    def lottery():
        nonlocal money
        lotteryTicket = []
        while True:
            clear()
            print("===== Lottery =====\n")
            print(f"Money: {money}")
            startBet = input("Place bet: ")
            if startBet.isdigit():
                startBet = int(startBet)
                if startBet > money:
                    print("Not enough money!")
                    time.sleep(1)
                else:
                    bet = int(startBet)
                    clear()
                    print("===== Lottery =====\n")
                    lotteryTicketInput = input("Fill out your lottery ticket (6 digits, 0-9): ")
                    if lotteryTicketInput.isdigit() and len(lotteryTicketInput) == 6:
                        lotteryTicketInput = [int(char) for char in lotteryTicketInput]
                        print("Drawing numbers...\n")

                        for _ in range(6):
                            lotteryTicketDraw = random.randint(0, 9)
                            lotteryTicket.append(lotteryTicketDraw)
                            time.sleep(0.5)

                        clear()
                        print("===== Lottery =====\n")
                        print(f"Drawn numbers: {lotteryTicket}")
                        print(f"Your numbers:  {lotteryTicketInput}")
                        time.sleep(1)
                        matches = sum(1 for a, b in zip(lotteryTicketInput, lotteryTicket) if a == b)
                        winAmount = bet * matches * 2
                        money += winAmount
                        money -= bet

                        print(f"\nYou matched {matches} number(s)!")
                        print(f"\n+{winAmount} Money")
                        print(f"Money: {money}")
                        time.sleep(5)

                        with open(userFile, "w") as f:
                            f.write(f"Money: {money}")
                        break
                    else:
                        print("Invalid ticket input! Must be 6 digits.")
                        time.sleep(1)
            else:
                print("Invalid bet input!")
                time.sleep(1)


    def slot():
        nonlocal money

        symbols = [
            "★","☻","✚","■","♠","♣","♥","♦","▲","7",
            "✶","✷","✦","✢","✤","✪","☎","✿","✾","✲",
            "☂","☃","☼","☾","❄","❖","☠","☮","✖","➐"
        ]

        def pairs(n):
            return range(n)

        while True:
            clear()
            print("===== Slot Machine =====\n")
            print(f"Money: {money}")
            userBet = input("Place bet: ")

            if not userBet.isdigit():
                print("Invalid input")
                time.sleep(1)
            else:
                userBet = int(userBet)
                bet = int(userBet)
                startBet = int(userBet)
                if userBet > money:
                    print("Not enough money!")
                    time.sleep(1)
                else:
                    break

        while True:
            clear()
            print("===== Slot Machine =====\n")
            print("-------------------")
            print("[ ] [ ] [ ] [ ] [ ]")
            print("-------------------")
            userInput = input("\nPress Enter to spin\nEnter 'exit' to leave: ").lower()
            if userInput == "exit":
                break
            elif userInput == "":
                if money >= userBet:
                    clear()
                    print("===== Slot Machine =====\n")

                    for i in pairs(50):
                        spin = [random.choice(symbols) for _ in range(5)]
                        time.sleep(0.05)
                        clear()
                        print("===== Slot Machine =====\n")
                        print("-------------------")
                        print(f"[{spin[0]}] [{spin[1]}] [{spin[2]}] [{spin[3]}] [{spin[4]}]")
                        print("-------------------")

                    final_symbols = [random.choice(symbols) for _ in range(5)]
                    clear()
                    print("===== Slot Machine =====\n")
                    print("-------------------")
                    print(f"[{final_symbols[0]}] [{final_symbols[1]}] [{final_symbols[2]}] [{final_symbols[3]}] [{final_symbols[4]}]")
                    print("-------------------\n")

                    counts = Counter(final_symbols)
                    most_common_count = counts.most_common(1)[0][1]

                    if most_common_count == 5:
                        payout = 50 * startBet
                        money += payout
                        print(f"$$$ JACKPOT! +{payout} Money")
                    elif most_common_count == 4:
                        payout = 25 * startBet
                        money += payout
                        print(f"Four of a kind! +{payout} Money")
                    elif most_common_count == 3:
                        payout = 10 * startBet
                        money += payout
                        print(f"Three of a kind! +{payout} Money")
                    elif most_common_count == 2:
                        payout = 3 * startBet
                        money += payout
                        print(f"Two of a kind! +{payout} Money")
                    else:
                        money -= startBet
                        print(f"No match")
                    with open(userFile, "w") as f:
                        f.write(f"Money: {money}")
                    print(f"Money: {money}")
                    time.sleep(3)
                else:
                    print("Not enough money!")
                    time.sleep(1)



    def roulette():
        nonlocal money
        while True:
            clear()
            print("===== Roulette =====\n")
            print(f"Money: {money}")
            userBet = input("Place bet: ")

            if not userBet.isdigit():
                print("Invalid input")
                time.sleep(1)
            else:
                userBet = int(userBet)
                bet = int(userBet)
                startBet = int(userBet)
                if userBet > money:
                    print("Not enough money!")
                    time.sleep(1)
                else:

                    break
        
        redNumbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
        blackNumbers = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35]
        evenNumbers = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36]
        oddNumbers = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35]
        lowNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
        highNumbers = [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36]
        dozen1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1]
        dozen2 = [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
        dozen3 = [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36]


        while True:
            clear()
            print("===== Roulette =====\n")
            print("Black | Red")
            print("Even  | Odd")
            print("Low   | High")
            print("1. Dozen")
            print("2. Dozen")
            print("3. Dozen")
            print("Straight-up (0-36)")
            userInput = input("\nPlace bet on a field or exit: ").lower()

            if userInput == "black" or userInput == "red" or userInput == "even" or userInput == "odd" or userInput == "low" or userInput == "high" or userInput == "1. dozen" or userInput == "2. dozen" or userInput == "3. dozen":
                betCategory = userInput
                break
            elif userInput.isdigit() and int(userInput) in range(0, 37):
                betCategory = int(userInput)
                break
            elif userInput == "exit":
                return
            else:
                print("Invalid input")
                time.sleep(1)

        while True:
            clear()
            print("===== Roulette =====\n")
            rouletteNumber = 0
            for i in range(random.randint(1,3)):
                for i in range(random.randint(0,36)):
                    time.sleep(0.075)
                    rouletteNumber += 1
                    if rouletteNumber > 36:
                        rouletteNumber = 0
                    clear()
                    print("===== Roulette =====\n")
                    print(f"[ {rouletteNumber-1} >{rouletteNumber}< {rouletteNumber+1} ]")

            if (betCategory == "black" and rouletteNumber in blackNumbers) or \
                (betCategory == "red" and rouletteNumber in redNumbers) or \
                (betCategory == "even" and rouletteNumber in evenNumbers) or \
                (betCategory == "odd" and rouletteNumber in oddNumbers) or \
                (betCategory == "low" and rouletteNumber in lowNumbers) or \
                (betCategory == "high" and rouletteNumber in highNumbers) or \
                (betCategory == "1. dozen" and rouletteNumber in highNumbers) or \
                (betCategory == "2. dozen" and rouletteNumber in highNumbers) or \
                (betCategory == "3. dozen" and rouletteNumber in highNumbers) or \
                (betCategory == rouletteNumber):
                    print("\nYou win!\n")
                    if (betCategory == "black") or \
                        (betCategory == "red") or \
                        (betCategory == "even") or \
                        (betCategory == "odd") or \
                        (betCategory == "low") or \
                        (betCategory == "high"):
                            money += bet * 2 - startBet
                            print(f"+{bet*2} Money")
                            with open(userFile, "w") as f:
                                f.write(f"Money: {money}")
                    if (betCategory == "1. dozen") or \
                        (betCategory == "2. dozen") or \
                        (betCategory == "3. dozen"):
                            money += bet *3 - startBet
                            print(f"+{bet*3} Money")
                            with open(userFile, "w") as f:
                                f.write(f"Money: {money}")
                    if (betCategory == rouletteNumber):
                            money += bet * 36 - startBet
                            print(f"+{bet*36} Money")
                            with open(userFile, "w") as f:
                                f.write(f"Money: {money}")
                    if (betCategory == 0 or "0") and\
                        (rouletteNumber == 0 or "0"):
                            money += bet * 50 - startBet
                            print(f"+{bet*50} Money")
                            with open(userFile, "w") as f:
                                f.write(f"Money: {money}")
            else:
                print("\nYou lose!\n")
                money -= startBet
                with open(userFile, "w") as f:
                    f.write(f"Money: {money}")
                
            print(f"Money: {money}")
            time.sleep(2)
            break

    games = [
        "Blackjack",
        "Lottery",
        "Slot",
        "Roulette",
    ]

    while True:
        clear()
        print("===== Casino =====\n")
        if money <= 0:
            print("No money detected! Granted 10 money")
            money += 10
            with open(userFile, "w") as f:
                f.write(f"Money: {money}")
            time.sleep(3)
        
        clear()
        print("===== Casino =====\n")

        for game in games:
            print(game)
        userInput = input("\n> ").lower()

        if userInput == "exit":
            break
        elif userInput == "blackjack":
            blackjack()
        elif userInput == "lottery":
            lottery()
        elif userInput == "slot":
            slot()
        elif userInput == "roulette":
            roulette()


# bank app
def bank_app(users, userFiles):
    currentUser = os.path.abspath(os.path.join(userFiles, ".."))
    userFile = os.path.abspath(os.path.join(currentUser, f"{os.path.basename(currentUser)}Money.txt"))
    with open(userFile, "r") as f:
        content = f.read()
    match = re.search(r"\d+", content)
    if match:
        value = int(match.group(0))
    else:
        print("No value found")
    
    balance = value

    while True:
        clear()
        print("===== Bank =====\n")
        print(f"Balance: {balance}")

        userInput = input("\n> ")

        if userInput == "exit":
            break
        else:
            print("Invalid input")
            time.sleep(1)