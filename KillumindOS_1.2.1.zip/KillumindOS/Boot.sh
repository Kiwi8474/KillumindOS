#!/bin/bash
python3 boot/Bootloader.py
