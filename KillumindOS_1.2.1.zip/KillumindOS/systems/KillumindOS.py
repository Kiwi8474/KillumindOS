import os
import time
import subprocess
import importlib.util
import shutil
import pickle
import traceback
import datetime
import platform
if os.name == "nt":
    try:
        import curses
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "windows-curses"])
        import curses
else:
    import curses

if os.name == "nt":
    os.system("chcp 65001 >nul")

# text engine
def type_print(text, speed=0.05):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(speed)
    print()


# terminal clear
def clear():
    os.system("cls" if os.name == "nt" else "clear")


# line replace
def replace_line(text, speed=0.05):
    clear()
    type_print(text, speed)


# dicts/paths
tasks = {
    "Language":{"Key": "1", "Status":"Unfinished"}, 
    "User Profile":{"Key": "2", "Status":"Unfinished"}
}

actionsDict = [
    "\nSystem",
    "   Terminal",
    "   File Manager",
    "   Settings",
    "   Calculator",
    "   Bank",
    "\nGames",
    "   Minesweeper",
    "   Snake",
    "   Casino",
    "\nLogout",
]

killumindos = os.path.join(os.path.dirname(os.path.abspath(__file__)), "killumindos")
files = os.path.join(killumindos, "files")
users = os.path.join(files, "users")

relativeActions = os.path.join(files, "actions.py")
absoluteActions = os.path.join(relativeActions)
modulename = "actions"

spec = importlib.util.spec_from_file_location(modulename, absoluteActions)
actions = importlib.util.module_from_spec(spec)
spec.loader.exec_module(actions)


# show wallpaper
def show_wallpaper(wallpaper):
    terminal_width = shutil.get_terminal_size().columns
    if wallpaper == "killua1":
        asciiArt = [
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠀⠀⠀⠀⢤⡀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣶⠖⠈⠀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣆⠀⠀⠀⣸⣿⣷⡀⠀⠀⢀⢴⣿⣿⣿⣿⣿⣿⣀⣀⣠⣶⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣦⡀⣸⣿⣿⣿⣿⣀⣴⣟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠸⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣬⣿⣿⣿⣿⣿⣿⣿⣟⣾⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻⣿⣿⡿⡿⣛⣯⣭⣭⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⣄⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣻⣿⣿⣛⡿⣿⣿⣟⢟⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣤⣤⣤⣤⣤⣤⣤⠆",
"⢀⡀⠀⠀⠀⠀⠀⠀⠘⠿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣟⣛⣿⣛⣻⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠀",
"⠈⢿⣿⣶⣶⣦⣤⣤⣴⣶⣾⣿⣿⣿⣿⣿⣿⣿⡿⣷⢟⣯⣶⣿⣿⣿⣿⣿⢯⡿⣿⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀",
"⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡿⣫⣷⣻⣿⣵⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣮⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣀⣀⠀⠀⠀",
"⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣳⣿⣿⣿⣽⡿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣻⢿⣾⣿⣿⣿⣿⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣏⠙⠋⠉⠉⠀⠀",
"⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⡿⣻⣿⣻⣿⣿⣿⣿⢿⣿⢽⣿⣏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣽⣿⣿⣿⣷⡻⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀",
"⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⡟⡿⣽⣿⣿⣿⢳⣿⣿⣿⣿⣿⣿⡿⣾⣿⣿⣻⣿⣽⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀",
"⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣹⢳⣿⣹⣿⡿⣿⣿⣾⣿⣿⣿⣿⡇⣿⣿⣿⣷⣽⣿⣟⣿⡇⣿⣿⣧⣿⣷⢿⣿⣿⡾⣿⣿⡿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀",
"⢀⡾⠟⠉⢀⣴⡿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣷⣿⡟⣿⣿⡿⣿⣿⡇⣿⣧⣿⣿⣿⣿⣾⣞⣣⣿⣿⣿⣸⣿⣾⣿⣿⣷⣿⣿⣇⣿⣽⣿⣿⣿⣿⣿⡉⠙⠛⠛⠋⠀⠀",
"⠈⠀⠀⢠⠞⢁⣼⣿⣿⣿⣸⡇⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣽⣿⠃⣿⣿⣿⣿⣿⣿⣿⣿⣿⡹⣿⣿⡏⣿⡏⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀",
"⠀⠀⠀⣀⣴⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣅⣻⠿⢿⣿⣿⡿⣿⢠⣿⣿⣿⣿⣿⣿⡇⣿⣿⢻⣻⣿⡇⡟⣷⣿⡻⣿⢻⣿⡟⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀",
"⠀⠐⢾⣿⣿⣿⣿⣿⣿⣿⣿⡧⣿⣿⢹⣿⣿⣽⣿⣼⣝⡻⢧⣿⢸⣹⣿⡸⣿⣿⣿⡇⣽⣿⣼⣷⣿⡿⢟⣫⣴⡾⣏⣸⣿⢷⣿⣿⣿⣿⣿⣏⢻⣿⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠈⠉⠙⠛⠛⣻⣿⣹⡏⣾⣿⣼⣿⠿⠷⠽⠿⠿⠿⣶⣌⠸⣷⢿⣿⣻⣿⣿⡇⣿⣻⣏⢟⣥⠶⠿⠃⠛⠛⠸⢿⡿⣼⣷⣿⣿⣿⣿⠹⡄⠹⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣧⢇⣿⡽⣿⡹⡇⢠⣾⣿⢷⠄⠀⠈⠘⢮⡻⡻⢯⣻⣿⣿⣿⣧⣳⢛⣉⠀⠀⠈⢻⣷⢀⡾⢻⡏⣾⣿⣿⣿⣿⣇⠀⠀⠙⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⣠⣿⡿⠟⣿⣠⣿⣿⣽⣏⣇⣧⡻⣿⢻⣦⣄⣴⢢⣷⣽⣿⣾⣷⡻⣿⣹⣟⣵⣇⣭⣤⣴⡾⣸⢏⡾⣰⡿⣿⣿⣿⡟⢿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠐⠉⠁⠀⠀⢹⣯⡻⣾⣿⣿⣿⣿⣿⣿⣷⡩⠯⠥⣟⣻⣿⣿⣿⣿⣿⣾⡿⣿⣿⣿⠶⠭⢝⣚⣿⣿⣿⣸⢟⣽⣳⣿⡇⠀⠈⠉⠛⠛⠂⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⠊⠉⢿⣾⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣵⢟⣵⢹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⢷⣯⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢷⡄⣿⠃⠀⠻⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⢿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣫⠻⠃⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠋⢻⡽⢿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠸⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠃⠀⠉⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢸⣾⣽⡻⣿⣿⣿⣿⣿⣿⣻⡗⠀⠀⠀⠀⠀⣸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣼⣿⠒⢄⠀⠀⠈⠛⠿⣿⣷⣯⣛⣻⣿⣿⣿⠃⠀⠀⠀⡠⣴⣿⣿⣿⣿⣷⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣾⣿⣿⣟⠀⠀⠑⢄⠀⠀⠀⠀⠉⠙⠛⠛⠛⠉⠀⠀⠀⡠⠁⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠈⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠊⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠁⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀⠀",
        ]
    elif wallpaper == "killua2":
        asciiArt = [
"⠛⠛⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⢫⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛",
"⠀⠀⠀⣿⣿⣿⣿⣿⣿⡿⢟⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣥⣦⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀",
"⣿⣿⣿⣿⣿⣿⣿⣟⣁⣶⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣉⣿⣿⣿⣿⣿⣿⣿⣶",
"⣿⣿⣿⣿⣿⣿⣿⣿⠿⣋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿",
"⡙⠿⠿⠿⠿⠟⣋⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠯⠻⠿⣿⣿⣿⠿⣫⣥⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⡙⠻⣿⣿⣿⣿",
"⣿⣄⡒⢶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣫⣤⣶⣿⡿⠛⣫⣥⣾⣿⣿⣽⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣌⠻⢿⣿",
"⠉⠉⠉⢠⣍⡛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢟⣩⡟⠁⢚⣩⣵⣶⢂⣶⣿⣿⡿⢿⣿⣿⣷⣬⣙⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣍",
"⣾⣿⣷⢼⣿⣿⣿⣶⠖⣈⣼⣿⣿⣿⣿⣿⡿⢋⣴⣿⡟⣠⣾⣿⣿⣿⣿⣌⢻⣿⣿⣌⠢⣙⣛⠿⠿⠿⠿⠿⠶⠖⣛⣉⣥⣶⣿⣿⣷⣦⣙⢿⣿⣿⣿⣿⣿⣿⣿⠿⡿⠿⠿⠛⢁",
"⣿⣿⣿⢸⣿⣿⠟⣡⡾⠿⠟⣿⣿⣿⣿⠟⣤⣿⣿⠟⣠⣿⠟⣿⣿⣿⣿⣿⡷⣬⡛⠿⢷⣬⣙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⠻⣿⣿⣿⣧⡙⢿⣿⣿⣿⣿⣿⣷⣄⡙⢿⡆⣾",
"⣿⣿⣿⢸⠟⠁⠨⠥⠖⣠⣾⣿⣿⣿⢋⣾⣿⣿⢋⣼⡿⢃⣾⣿⢋⣿⣿⠟⣴⣿⣿⣷⣶⣮⣭⣥⣬⣭⣹⣏⠻⣿⣿⣏⠻⣿⣿⣷⡌⢿⣿⣿⣿⡌⢿⣿⣿⣿⣿⠛⠛⠿⣌⠳⣿",
"⢿⣿⡇⢸⣿⣿⣿⠏⣼⣿⣿⣿⣿⠇⣾⣿⣿⢃⣾⡟⣱⣿⣿⢃⣾⣿⠏⣼⡿⢹⣿⣿⣿⢹⣿⣿⢿⣿⣿⣿⣷⡙⢿⣿⣷⡙⣿⣿⣿⣎⠻⣿⣿⣷⡘⣿⣿⣿⣿⣷⡜⢷⣮⡀⢽",
"⠈⠉⠁⢸⡿⠟⣡⣾⣿⣿⣿⣿⠟⢸⣿⡿⠃⣾⡿⢱⣿⡿⠃⣾⡿⠃⢸⣿⠃⣼⣿⣿⠏⠘⣿⣿⠀⠙⢿⣿⣿⣷⠀⢉⢿⣿⡜⢿⣿⣿⡄⠈⢻⣿⣇⢿⣿⣿⣿⣿⣷⡌⢿⡇⠀",
"⠀⠀⠐⠲⢶⣿⣿⣿⣿⣿⣿⣿⠇⣿⣿⠃⢰⣿⠇⣿⡿⠁⢀⣿⡃⠀⣿⣇⠀⢿⣿⣿⠀⠀⠻⣿⡄⢸⣆⠙⣿⣿⡇⠀⠂⠻⣷⡀⢻⣿⣿⠀⠀⢻⣿⠘⢷⡘⡻⣿⣿⣿⣦⡀⠄",
"⠀⠀⠀⢸⣶⣤⣬⣭⠭⢉⣤⠟⠀⣿⠏⢀⢸⡏⠀⣿⢣⠃⡜⣿⠇⡄⣿⣿⠁⢸⣿⡏⣶⡆⠀⠻⣇⠀⢋⡤⠈⢿⣗⠠⣄⠀⢻⡇⠀⢻⣿⠀⣶⡀⣿⠀⠈⣷⡈⠢⠬⠙⠻⠿⠂",
"⠀⠀⠀⢈⣥⣬⣭⣍⠁⣼⠃⠀⡀⢿⠀⣼⢸⢃⠀⣿⡟⠀⠁⠟⠀⠑⢸⣿⢀⡎⢻⡇⣿⠁⢠⡄⠑⢤⠀⣴⣶⠄⠛⠰⠺⠆⢾⡇⡀⠈⣿⠀⣉⠁⠈⢀⠈⣼⣇⢀⣀⣀⣐⡂⠀",
"⠀⢠⡄⢸⣿⣿⣿⣿⠀⠋⡔⢸⣿⠸⠀⣛⠀⣿⠀⠀⠀⠀⠀⠀⢀⡀⠀⠁⠀⠙⢆⠻⣿⣇⠈⠄⣿⡦⠁⠀⠀⠁⡈⢀⠁⠀⠸⡇⠃⠸⢹⠐⠛⢣⠀⣿⡇⠘⢻⠈⣿⣿⣿⡇⠀",
"⠴⠿⠇⢸⣿⣿⣿⣿⣀⣾⡇⢸⣿⣧⢸⠟⠃⠙⠀⣦⠀⣴⣾⣿⣿⣛⠉⠂⣴⡈⢺⣷⡙⢿⣆⠃⢸⡁⠀⣀⡐⠛⢷⣿⣷⣦⡄⢀⡴⠀⠃⠘⣏⣼⠐⣿⡇⡀⠀⢠⣿⣿⣿⡇⠀",
"⠀⠀⠀⢸⣿⣿⣿⣿⣿⡟⣠⣿⣿⠇⣼⢨⠉⡀⠀⢸⣷⣿⣿⣿⠛⠿⠁⠀⠸⣿⣴⣿⣿⣶⣌⡀⢊⣴⡟⠻⠟⠀⠀⢹⣿⣿⣃⣾⠇⠀⣼⡇⣿⡿⢀⣿⡇⣷⣴⣿⣿⣿⣿⡇⠀",
"⠀⠀⡀⢸⡟⢿⠿⠿⠃⠐⠛⠉⢭⠄⠹⣿⡄⠻⣄⡈⣿⣿⣧⡙⠄⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⡼⢟⣿⣿⡿⠀⠼⢋⣴⠿⠁⢘⠛⠧⢸⣿⣿⣿⣿⣿⣷⣿",
"⠄⠀⠃⠀⠻⠀⠀⢠⣶⡶⠶⣦⠤⠾⠧⠈⠛⢷⣤⣁⠸⣿⣿⣿⣶⣤⣤⣶⣾⣿⣿⣿⠉⣿⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣿⣿⣿⡇⣶⣶⠟⠁⠀⢠⠀⠀⠀⢀⣤⣤⣭⣭⣽⣏⣿",
"⠀⠁⠀⢠⡄⠘⠀⠀⢍⢛⠀⠈⠁⠀⠀⣶⠀⠀⣙⠛⠃⠀⣶⣶⢸⣿⣿⣿⣿⣿⣿⡄⠰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢁⡍⠁⢰⣿⣶⡌⠁⠀⠀⠸⢿⣿⣿⣿⣿⣿⣿",
"⠀⠉⠁⠈⢀⣄⡀⠈⠀⠴⠧⣼⠆⠀⠀⠁⠀⠀⠈⢀⣶⠀⢿⣿⡎⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢋⡉⢿⡿⢃⠀⠁⠀⢠⣦⡀⠁⢸⣿⣶⣷⣦⣿⣿⠛⣿⣿⣿",
"⠀⣦⡤⠀⠀⡉⠁⢄⠀⠀⠀⢀⡄⠀⠀⢠⣤⡀⢀⣈⠀⠀⠈⠛⢿⠆⣻⣿⣿⣿⣿⣟⡛⠿⣿⣿⣿⣿⣿⣿⣧⠸⡿⠟⠀⢠⠏⢠⠒⢠⣄⠃⠀⢀⣈⡁⢬⠟⢻⣿⣷⠶⢿⡇⠀",
"⠤⠀⠀⠘⠆⢿⠀⠀⠀⠀⠀⠈⠁⣄⡀⠈⠅⠀⠀⠰⡶⢀⣄⢤⠀⠈⠛⢿⣿⣿⣿⣿⣛⢳⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⣶⡆⠠⣄⣀⠀⠻⠯⠃⠀⠐⠏⣿⣿⠿⣿⡿⠲",
"⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⢀⣉⠀⠀⢀⣤⣤⣤⣴⣿⡏⠘⠀⠀⠂⠀⠈⠙⠻⢿⣿⣿⣿⣿⡿⠛⣩⣴⣶⡀⠀⠸⠁⠂⠀⡏⣿⣧⡈⠛⠓⠀⠀⠀⣴⣤⠾⣤⠛⣶⣷⣷⣴",
"⠀⠀⠀⠈⢿⠟⠀⠀⠀⠀⠀⠀⠉⠋⠀⠀⣾⣿⣿⣿⣿⣿⣷⠸⣆⠀⠀⠀⣶⣧⣹⣶⣬⣉⣉⣡⣶⣿⣿⣿⣿⣿⠃⠀⠀⠀⡀⢠⣿⣿⣿⣶⣾⣿⣷⣦⡈⣡⣄⢸⡿⣿⣿⡿⣏",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⣡⣶⣿⣿⣇⠹⣿⣿⣿⣿⣿⣿⡆⢻⣦⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⡤⠂⢀⡴⢡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠻⠤⣉⣿⣿⣍⣙",
"⢀⠀⣈⣁⠐⢦⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣆⠻⣿⣿⣿⣿⣿⣿⡄⢿⣦⡀⠘⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⡔⠂⢀⣴⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⡿⠛⣡⣴⣶⣤⡁⠈⠛⣿⣿",
"⣾⠉⠀⠉⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣦⡙⢿⣄⠀⠀⢉⠻⣿⣿⣿⠟⡁⠀⠀⣠⠶⠛⣡⣴⣿⣿⣿⣿⣟⣻⡿⠟⣩⣴⣿⣿⣿⣿⣿⣿⣦⠀⠹⠳",
"⠉⠀⠀⠀⠀⣴⣿⣿⣿⣿⡇⠘⣿⣿⣿⣿⣿⣿⡿⠦⠙⠻⣿⣿⣿⣿⣿⣶⣤⣅⡀⠘⠓⠄⠉⠥⡺⠁⣀⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⡟⢋⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀",
"⣀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣇⠀⢻⡻⠸⠿⢋⣡⣶⣾⣶⣶⣶⣶⣬⡙⠻⢿⡿⠿⣿⣆⠹⣿⣿⡟⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢉⣴⣿⣿⣿⣿⣿⣿⣿⠙⣿⣿⣿⣿⣿⡇⠀",
"⣉⣀⣴⣿⣿⣿⣿⣿⣿⣿⠛⣠⣶⣦⣀⠿⣿⣿⣿⠿⠿⠿⠿⠿⠿⣿⣷⣦⣄⠀⣀⡙⠇⢹⣿⢣⡿⠛⠉⠼⠛⠛⠛⣛⣛⣉⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⣿⣿⣿⣿⣿⣧⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⠛⢁⣬⣿⣿⣿⣿⣷⣌⡉⠀⣠⢤⢴⡦⠠⣬⣄⣈⡉⠤⢾⡿⢿⡶⢠⠀⢤⣤⠶⠀⠀⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢀⣿⣿⣿⣿⣿⣿⠀",
        ]
    elif wallpaper == "killua3":
        asciiArt = [
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣛⠛⢭⣭⣽⣛⡛⠛⠿⣿⣿⣿⣿⣿⢉⡙⢿⣿⡛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣙⠛⠒⠮⠙⢿⣿⣿⣿⣶⣮⣍⡛⢿⡇⣿⣦⡙⣧⢱⡘⣿⣿⣿⣿⢏⣴⢸⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡍⢉⣉⣉⣉⣉⣉⣉⣁⣙⠳⣶⣦⣽⣿⣿⣿⣿⣿⣿⣶⡅⢻⣿⣷⡈⢸⣷⠘⣿⠟⣡⣿⣿⢸⣿⡏⣉⣿⣽⠘⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⣿⡆⣱⣾⣿⣿⠇⠼⢛⣡⣤⣤⣤⣤⠤⠈⢹⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⢃⣙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⠏⣠⣾⣿⣿⣿⣿⡿⢁⣰⣻⣥⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣩⣵⣶⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⡟⠠⢤⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠏⡥⡾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣿⣿⡟⠀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⠶⠷⢒⣀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣿⣿⣿⡇⡄⣿⣿⣿⠋⣿⣿⣿⣿⣿⣏⣁⣀⠀⠆⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣀⠲⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⢄⣒⣛⣛⢦⠻⠛⡱⢃⡿⢟⡁⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣷⣮⣝⡛⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⣴⣾⣿⣿⣿⣿⣦⡐⣤⡐⢒⣒⣩⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⡿⠟⣛⣥⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡌⣷⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣴⣶⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⠀⢰⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⣿⠀⣿⣿⣿⣿⣟⠻⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣷⣌⠻⣷⣿⣿⣿⣿⣷⣾⣷⣶⢖⣨⣾⡿⠟⢩⣿⡿⠋⣼⣿⢿⣿⣿⣿⢃⣿⣿⠟⣿⣿⣿⢹⣿⣿⢏⣼⠟⣴⢿⣿⡿⣿⡏⢿⣦⡙⢿⣿⣿⣿⣿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣷⣬⡛⢿⣿⣿⣿⣿⣿⣯⣛⣭⣴⡾⣳⡿⢋⠀⣾⠟⣡⣿⣿⠿⠁⣾⣿⣿⠀⣿⣿⡇⠘⠋⢕⣛⣥⣾⣿⠈⢿⣧⠘⣿⣆⠻⣿⣮⠻⣍⡊⢡⣴⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⢂⣭⣿⣿⣿⣿⣿⣿⣿⣿⣣⢏⣴⠟⣼⣧⡆⣿⣿⢏⠀⣼⣿⣿⠏⢀⣿⣿⠣⢰⣶⠘⣿⣿⣿⣿⣶⠘⣿⡆⢿⣿⡄⠝⢿⣧⠹⣿⣎⢻⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⡿⠵⠾⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣾⡿⣿⣿⣿⡡⠁⣸⣿⣿⠏⡖⢸⣿⣏⡄⡆⣿⡇⢻⡿⣿⣿⣿⡇⢻⣧⠸⣿⣿⢸⣆⢻⣇⢉⠻⡄⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠟⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⡏⣸⣿⢃⣿⣿⠗⣠⢡⣿⡿⢫⡞⠀⣾⣿⡿⢡⡇⢸⡟⠀⣿⣿⠿⡿⢁⠸⣿⠀⢹⣿⡈⣿⣆⢻⠘⣷⡁⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢰⣿⣿⢸⣿⡟⣰⡇⣸⣿⡿⢂⡈⠐⠿⠿⠣⢞⠁⣉⠁⡇⣻⣯⡙⢁⣈⡄⡟⣸⡇⣿⢇⣿⣿⡆⡇⣹⣿⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣀⣙⣛⣛⡻⠿⣿⣿⣿⣿⣿⡿⢃⣤⣤⡋⢸⣿⢱⣿⢱⣿⠟⣡⣿⢣⣿⠏⢴⣿⠛⣼⢃⣾⡇⣿⡿⢃⣾⠿⠃⠡⢿⠆⠸⢸⣿⣿⣧⢰⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣙⠻⣿⣿⢡⣴⣦⣌⠻⢸⣿⢸⣿⢈⡕⠚⡉⠀⢊⣀⡒⠶⠌⠀⣵⡿⢉⠀⢟⣵⣯⠕⢈⢀⣶⣿⢸⠀⠙⢿⣿⣿⠘⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡐⢤⣶⣶⣿⣿⢸⣿⣿⣿⠀⣧⠻⢸⣿⣿⣿⢙⠁⠴⢿⣿⣿⣷⣤⣼⡟⣱⣿⣴⣿⣿⣯⣾⣿⣿⣿⣿⢸⣿⡐⠲⣬⣉⡁⣹⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣬⣙⠻⠿⢆⠻⣝⢿⣧⡙⣃⡈⣿⣿⣿⣿⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⠈⡻⠧⠈⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⢼⡗⠌⠛⢦⣼⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣿⡿⣿⣿⣿⡿⠈⣿⣦⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⢡⣿⣦⠀⢀⠀⠹⣿⣿⣿⣿⣿⣿⡏⣶⣮⣭⣟⣛⣛⣛⣛⣻⣭⣭⡥⡂⣸⣿⡿⢁⣤⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⡆⠘⣽⡆⠈⠻⣿⣿⣿⣿⡇⢍⢫⣭⣽⣿⣿⣿⣿⠿⠛⣫⣭⣶⡿⢋⣰⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢡⡄⠙⣿⣆⠑⢌⡛⠿⣿⣿⣦⣭⣉⣉⣭⣭⣶⣶⣿⣿⣿⠟⢋⣴⣿⣿⣿⣿⣿⣿⡀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⣋⣡⣶⣶⠹⣿⣄⠙⠿⣷⣄⡙⠻⢶⣭⣙⡻⠿⠿⣿⣿⣿⣿⣿⠟⢁⣐⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣛⣡⣴⣿⣿⣿⣿⣿⣦⡘⢿⣧⣷⣿⣿⣿⣷⣤⠤⣬⣍⣉⠋⠀⢠⣤⣤⠄⣰⣿⣿⣿⣿⣶⣤⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠋⣡⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡙⢿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣷⣿⣿⡟⢡⣶⣿⣿⣿⣿⣿⣿⣿⣷⡈⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⠿⠿⠿⠿⠿⠿⠿⠃⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠦⠹⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠀⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠹⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀",
        ]
    else:
        print("No Wallpaper selected or Failure")
        return

    for line in asciiArt:
        print(line.ljust(terminal_width))


# start
def startup():
    clear()
    type_print("===== Welcome to KillumindOS 1.2 =====\n\n")
    time.sleep(1)
    if os.path.exists(os.path.join(files, "setup.txt")):
        print("Starting KillumindOS")
        time.sleep(1)
        for i in range(50):
            print(os.path.dirname)
            print(os.path.dirname(os.path.abspath(__file__)))
            time.sleep(0.01)
        start_os()
        return
    else:
        type_print("Let's start with the setup of KillumindOS")
        time.sleep(1)
        setup()
        return


def setup():
    clear()
    
    if all(details["Status"] == "Finished" for details in tasks.values()):
        type_print("===== Setup Menu =====\n")
        type_print("Your setup is complete!")
        type_print("KillumindOS will now be started")
        with open(os.path.join(files, "setup.txt"), "w") as f:
            f.write("")
        time.sleep(1)
        start_os()
        return

    type_print("===== Setup Menu =====\n")
    for task, details in tasks.items():
        print(f"{task}: {details['Status']} - {details['Key']}")
        time.sleep(0.4)

    type_print("\nSelect any task\n")

    while True:
        taskChoice = input("> ")
        
        selected_task = None
        for task, details in tasks.items():
            if taskChoice == details["Key"]:
                selected_task = task
                break
        
        if selected_task:
            execute_task(selected_task)
            break
        else:
            type_print("Invalid input", 0.01)


# execute task
def execute_task(task_name):
    if task_name == "Language":
        setup_language()
    elif task_name == "User Profile":
        setup_profile()

# language
def setup_language():
    languages = {
        "English": "1",
        "German": "2"
    }

    clear()
    type_print("===== Language Manager =====\n")
    type_print("Choose your language:\n")
    time.sleep(1)

    for language, key in languages.items():
        print(f"{language} - {key}")
        time.sleep(0.4)

    while True:
        languageChoice = input("> ")
        if languageChoice in languages.values():
            selectedLanguage = [key for key, value in languages.items() if value == languageChoice][0]
            break
        elif languageChoice == "2":
            type_print("German translation is still under development")
            time.sleep(0.5)
        else:
            type_print("Invalid input", 0.01)
    type_print(f"\nGreat! You set your language to {selectedLanguage}")
    time.sleep(1)
    tasks["Language"]["Status"] = "Finished"
    setup()

# profile
def setup_profile():
    Users = {}
    clear()
    type_print("===== User Manager =====\n")
    type_print("Let's create a User Profile for you\n")

    type_print("Let's start with your username\n")
    time.sleep(1)
    username = input("Username: ")

    type_print("Great! Now to your password\n")
    time.sleep(1)
    password = input("Password: ")

    type_print("Good. Your user profile is all set ")
    time.sleep(1)

    os.makedirs(os.path.join(users, username), exist_ok=True)
    with open(os.path.join(users, username,f"{username}.txt"), "w") as f:
        f.write(f"Username: {username}\nPassword: {password}")
    with open(os.path.join(users, username, f"{username}Money.txt"), "w") as f:
        f.write(f"Money: 100")

    userFiles = os.path.join(users, username, "userFiles")
    os.makedirs(userFiles, exist_ok=True)


    tasks["User Profile"]["Status"] = "Finished"
    setup()

# action handler
def action_handler(userInput, userFiles):
    if userInput == "terminal":
        clear()
        actions.terminal(userFiles)
    elif userInput == "file manager":
        clear()
        actions.file_manager(userFiles)
    elif userInput == "settings":
        clear()
        actions.settings(userFiles)
    elif userInput == "minesweeper":
        clear()
        actions.minesweeper()
    elif userInput == "snake":
        clear()
        score = curses.wrapper(actions.snake)
    elif userInput == "calculator":
        clear()
        actions.calculator()
    elif userInput == "casino":
        clear()
        actions.casino(users, userFiles)
    elif userInput == "bank":
        clear()
        actions.bank_app(users, userFiles)

# load wallpaper
def load_wallpaper(userFiles):
    try:
        with open(os.path.join(userFiles, "wallpapers", "wallpaper_auswahl.pkl"), "rb") as file:
            savedWallpaper = pickle.load(file)
            show_wallpaper(savedWallpaper)
    except FileNotFoundError:
        print("No wallpaper saved")
    except Exception as e:
        print(f"[ERROR] Unable to load wallpaper: {e}")


# start os
def start_os():
    while True:
        clear()
        print("========== Login ==========\n")
        usernameInput = input("Username: ")
        userFile = os.path.join(users, usernameInput,f"{usernameInput}.txt")

        if os.path.exists(userFile):
            with open(userFile, "r", encoding="utf-8") as f:
                lines = f.readlines()

            savedUsername = lines[0].split(":")[1].strip()
            savedPassword = lines[1].split(":")[1].strip()

            passwordInput = input("Password: ")

            if usernameInput == savedUsername and passwordInput == savedPassword:
                userDir = os.path.join(users, usernameInput)
                userFiles = os.path.join(userDir, "userFiles")
                break
            else:
                type_print("\nUsername or password incorrect")
                time.sleep(0.5)
        else:
            type_print("\nUsername not found")
            time.sleep(0.5)

    while True:
        clear()
        load_wallpaper(userFiles)
        print("========== Desktop ==========\n")
        for action in actionsDict:
            print(action)
        print("")
        userInput = input("> ").lower()
        action_handler(userInput, userFiles)
        if userInput == "logout":
            break


startup()
print("\n\n[SYSTEM] END\n")
time.sleep(0.5)
subprocess.run(["python3", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "boot", "end.py")])
