import subprocess
import os
import time


print("Prozesse beendet.")
time.sleep(1)
for i in range(50):
    print(os.path.dirname)
    print(os.path.dirname(os.path.abspath(__file__)))
    time.sleep(0.01)

subprocess.run(["python3", os.path.join(os.path.dirname(os.path.abspath(__file__)), "Bootloader.py")])