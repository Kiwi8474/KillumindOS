import os
import shutil
import time
import pickle
import random


# clear console
def clear():
    os.system("clear")


# terminal
def terminal(userFiles):
    while True:
        userInput = input(f"{os.path.dirname(os.path.abspath(__file__))}/ > ").lower()

        if userInput == "exit":
            break

        elif userInput == "ls":
                try:
                    files = os.listdir(userFiles)
                    if not files:
                        print("This folder is empty")
                    else:
                        for file in files:
                            print(f"- {file}")
                except FileNotFoundError:
                    print("Folder not found")
                except Exception as e:
                    print(f"[ERROR]: {e}")
        else:
            print(f"command '{userInput}' not found")


# file manager
def file_manager(userFiles):
    currentFolder = userFiles
    while True:
        clear()
        print("===== File Manager =====")
        files = os.listdir(currentFolder)

        if files:
            print(f"\nCurrent folder: {currentFolder}\n")
            for file in files:
                print(file)
        else:
            print(f"\nCurrent folder: {currentFolder}\n")
            print("No files in this folder")
        userInput = input("\n> ").lower()

        if userInput == "exit":
            break

        elif userInput == "create file":
            fileName = input("File name: ")
            with open(os.path.join(currentFolder, fileName), "w") as f:
                f.write("")

        elif userInput == "create folder":
            folderName = input("Folder name: ")
            os.makedirs(os.path.join(currentFolder, folderName), exist_ok=True)

        elif userInput == "enter":
            folderName = input("Folder to enter: ")
            newPath = os.path.join(currentFolder, folderName)
            if os.path.isdir(newPath):
                currentFolder = newPath
            else:
                print(f"Folder '{folderName}' not found.")
                time.sleep(1)
        
        elif userInput == "delete":
            fileToDelete = input("File to delete: ")
            if os.path.isfile(os.path.join(currentFolder, fileToDelete)):
                os.remove(os.path.join(currentFolder, fileToDelete))
            elif os.path.isdir(os.path.join(currentFolder, fileToDelete)):
                shutil.rmtree(os.path.join(currentFolder, fileToDelete))
            else:
                print(f"File '{fileToDelete}' not found")
                time.sleep(1)

        elif userInput == "back":
            parent = os.path.dirname(currentFolder)
            if os.path.exists(parent) and parent.startswith(userFiles):
                currentFolder = parent
            else:
                print("You are already in the main folder")
                time.sleep(1)
        
        elif userInput == "edit":
            fileToEdit = input("File to edit: ")
            if os.path.isfile(os.path.join(currentFolder, fileToEdit)):
                text_editor(os.path.join(currentFolder, fileToEdit))
            else:
                print(f"File '{fileToEdit}' not found or is not a file")
                time.sleep(1)


# text editor
def text_editor(fileToEdit):
    while True:
        clear()
        print("\n===== Text Editor =====")
        print(f"Current file: {fileToEdit}\n")

        if os.path.isfile(fileToEdit):
            with open(fileToEdit, "r") as f:
                content = f.read()
        else:
            content = "[File not found]"

        print("--- File Content ---")
        print(content if content else "[Empty file]")
        print("--------------------\n")

        userInput = input("> ").lower()

        if userInput == "write":
            newText = input("Text to append: ")
            with open(fileToEdit, "a") as f:
                f.write(newText + "\n")

        elif userInput == "clear":
            confirm = input("Are you sure? (yes/no): ")
            if confirm.lower() == "yes":
                with open(fileToEdit, "w") as f:
                    f.write("")

        elif userInput == "exit":
            break

        else:
            print("Unknown command.")
            time.sleep(1)


# wallpapers
wallpapers = {
    "killua1": [
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠀⠀⠀⠀⢤⡀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣶⠖⠈⠀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣆⠀⠀⠀⣸⣿⣷⡀⠀⠀⢀⢴⣿⣿⣿⣿⣿⣿⣀⣀⣠⣶⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣦⡀⣸⣿⣿⣿⣿⣀⣴⣟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠸⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣬⣿⣿⣿⣿⣿⣿⣿⣟⣾⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻⣿⣿⡿⡿⣛⣯⣭⣭⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⣄⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣻⣿⣿⣛⡿⣿⣿⣟⢟⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣤⣤⣤⣤⣤⣤⣤⠆",
"⢀⡀⠀⠀⠀⠀⠀⠀⠘⠿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣟⣛⣿⣛⣻⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠀",
"⠈⢿⣿⣶⣶⣦⣤⣤⣴⣶⣾⣿⣿⣿⣿⣿⣿⣿⡿⣷⢟⣯⣶⣿⣿⣿⣿⣿⢯⡿⣿⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀",
"⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡿⣫⣷⣻⣿⣵⣿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣮⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣀⣀⠀⠀⠀",
"⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣳⣿⣿⣿⣽⡿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣻⢿⣾⣿⣿⣿⣿⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣏⠙⠋⠉⠉⠀⠀",
"⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⡿⣻⣿⣻⣿⣿⣿⣿⢿⣿⢽⣿⣏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣽⣿⣿⣿⣷⡻⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀",
"⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⡟⡿⣽⣿⣿⣿⢳⣿⣿⣿⣿⣿⣿⡿⣾⣿⣿⣻⣿⣽⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⡽⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀",
"⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣹⢳⣿⣹⣿⡿⣿⣿⣾⣿⣿⣿⣿⡇⣿⣿⣿⣷⣽⣿⣟⣿⡇⣿⣿⣧⣿⣷⢿⣿⣿⡾⣿⣿⡿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀",
"⢀⡾⠟⠉⢀⣴⡿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣷⣿⡟⣿⣿⡿⣿⣿⡇⣿⣧⣿⣿⣿⣿⣾⣞⣣⣿⣿⣿⣸⣿⣾⣿⣿⣷⣿⣿⣇⣿⣽⣿⣿⣿⣿⣿⡉⠙⠛⠛⠋⠀⠀",
"⠈⠀⠀⢠⠞⢁⣼⣿⣿⣿⣸⡇⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣽⣿⠃⣿⣿⣿⣿⣿⣿⣿⣿⣿⡹⣿⣿⡏⣿⡏⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀",
"⠀⠀⠀⣀⣴⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣅⣻⠿⢿⣿⣿⡿⣿⢠⣿⣿⣿⣿⣿⣿⡇⣿⣿⢻⣻⣿⡇⡟⣷⣿⡻⣿⢻⣿⡟⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀",
"⠀⠐⢾⣿⣿⣿⣿⣿⣿⣿⣿⡧⣿⣿⢹⣿⣿⣽⣿⣼⣝⡻⢧⣿⢸⣹⣿⡸⣿⣿⣿⡇⣽⣿⣼⣷⣿⡿⢟⣫⣴⡾⣏⣸⣿⢷⣿⣿⣿⣿⣿⣏⢻⣿⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠈⠉⠙⠛⠛⣻⣿⣹⡏⣾⣿⣼⣿⠿⠷⠽⠿⠿⠿⣶⣌⠸⣷⢿⣿⣻⣿⣿⡇⣿⣻⣏⢟⣥⠶⠿⠃⠛⠛⠸⢿⡿⣼⣷⣿⣿⣿⣿⠹⡄⠹⣿⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣧⢇⣿⡽⣿⡹⡇⢠⣾⣿⢷⠄⠀⠈⠘⢮⡻⡻⢯⣻⣿⣿⣿⣧⣳⢛⣉⠀⠀⠈⢻⣷⢀⡾⢻⡏⣾⣿⣿⣿⣿⣇⠀⠀⠙⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⣠⣿⡿⠟⣿⣠⣿⣿⣽⣏⣇⣧⡻⣿⢻⣦⣄⣴⢢⣷⣽⣿⣾⣷⡻⣿⣹⣟⣵⣇⣭⣤⣴⡾⣸⢏⡾⣰⡿⣿⣿⣿⡟⢿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠐⠉⠁⠀⠀⢹⣯⡻⣾⣿⣿⣿⣿⣿⣿⣷⡩⠯⠥⣟⣻⣿⣿⣿⣿⣿⣾⡿⣿⣿⣿⠶⠭⢝⣚⣿⣿⣿⣸⢟⣽⣳⣿⡇⠀⠈⠉⠛⠛⠂⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⠊⠉⢿⣾⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣵⢟⣵⢹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⢷⣯⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢷⡄⣿⠃⠀⠻⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⢿⣷⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣫⠻⠃⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠋⢻⡽⢿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠸⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠃⠀⠉⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢸⣾⣽⡻⣿⣿⣿⣿⣿⣿⣻⡗⠀⠀⠀⠀⠀⣸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣼⣿⠒⢄⠀⠀⠈⠛⠿⣿⣷⣯⣛⣻⣿⣿⣿⠃⠀⠀⠀⡠⣴⣿⣿⣿⣿⣷⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣾⣿⣿⣟⠀⠀⠑⢄⠀⠀⠀⠀⠉⠙⠛⠛⠛⠉⠀⠀⠀⡠⠁⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠈⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠊⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠁⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⡇⠀⠀⠀⠀⠀⠀⠀",
"⠀⠀⠀⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀⠀",
],
    "killua2": [
"⠛⠛⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⢫⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛",
"⠀⠀⠀⣿⣿⣿⣿⣿⣿⡿⢟⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣥⣦⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀",
"⣿⣿⣿⣿⣿⣿⣿⣟⣁⣶⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣉⣿⣿⣿⣿⣿⣿⣿⣶",
"⣿⣿⣿⣿⣿⣿⣿⣿⠿⣋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿",
"⡙⠿⠿⠿⠿⠟⣋⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠯⠻⠿⣿⣿⣿⠿⣫⣥⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⡙⠻⣿⣿⣿⣿",
"⣿⣄⡒⢶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣫⣤⣶⣿⡿⠛⣫⣥⣾⣿⣿⣽⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣌⠻⢿⣿",
"⠉⠉⠉⢠⣍⡛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢟⣩⡟⠁⢚⣩⣵⣶⢂⣶⣿⣿⡿⢿⣿⣿⣷⣬⣙⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣍",
"⣾⣿⣷⢼⣿⣿⣿⣶⠖⣈⣼⣿⣿⣿⣿⣿⡿⢋⣴⣿⡟⣠⣾⣿⣿⣿⣿⣌⢻⣿⣿⣌⠢⣙⣛⠿⠿⠿⠿⠿⠶⠖⣛⣉⣥⣶⣿⣿⣷⣦⣙⢿⣿⣿⣿⣿⣿⣿⣿⠿⡿⠿⠿⠛⢁",
"⣿⣿⣿⢸⣿⣿⠟⣡⡾⠿⠟⣿⣿⣿⣿⠟⣤⣿⣿⠟⣠⣿⠟⣿⣿⣿⣿⣿⡷⣬⡛⠿⢷⣬⣙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⠻⣿⣿⣿⣧⡙⢿⣿⣿⣿⣿⣿⣷⣄⡙⢿⡆⣾",
"⣿⣿⣿⢸⠟⠁⠨⠥⠖⣠⣾⣿⣿⣿⢋⣾⣿⣿⢋⣼⡿⢃⣾⣿⢋⣿⣿⠟⣴⣿⣿⣷⣶⣮⣭⣥⣬⣭⣹⣏⠻⣿⣿⣏⠻⣿⣿⣷⡌⢿⣿⣿⣿⡌⢿⣿⣿⣿⣿⠛⠛⠿⣌⠳⣿",
"⢿⣿⡇⢸⣿⣿⣿⠏⣼⣿⣿⣿⣿⠇⣾⣿⣿⢃⣾⡟⣱⣿⣿⢃⣾⣿⠏⣼⡿⢹⣿⣿⣿⢹⣿⣿⢿⣿⣿⣿⣷⡙⢿⣿⣷⡙⣿⣿⣿⣎⠻⣿⣿⣷⡘⣿⣿⣿⣿⣷⡜⢷⣮⡀⢽",
"⠈⠉⠁⢸⡿⠟⣡⣾⣿⣿⣿⣿⠟⢸⣿⡿⠃⣾⡿⢱⣿⡿⠃⣾⡿⠃⢸⣿⠃⣼⣿⣿⠏⠘⣿⣿⠀⠙⢿⣿⣿⣷⠀⢉⢿⣿⡜⢿⣿⣿⡄⠈⢻⣿⣇⢿⣿⣿⣿⣿⣷⡌⢿⡇⠀",
"⠀⠀⠐⠲⢶⣿⣿⣿⣿⣿⣿⣿⠇⣿⣿⠃⢰⣿⠇⣿⡿⠁⢀⣿⡃⠀⣿⣇⠀⢿⣿⣿⠀⠀⠻⣿⡄⢸⣆⠙⣿⣿⡇⠀⠂⠻⣷⡀⢻⣿⣿⠀⠀⢻⣿⠘⢷⡘⡻⣿⣿⣿⣦⡀⠄",
"⠀⠀⠀⢸⣶⣤⣬⣭⠭⢉⣤⠟⠀⣿⠏⢀⢸⡏⠀⣿⢣⠃⡜⣿⠇⡄⣿⣿⠁⢸⣿⡏⣶⡆⠀⠻⣇⠀⢋⡤⠈⢿⣗⠠⣄⠀⢻⡇⠀⢻⣿⠀⣶⡀⣿⠀⠈⣷⡈⠢⠬⠙⠻⠿⠂",
"⠀⠀⠀⢈⣥⣬⣭⣍⠁⣼⠃⠀⡀⢿⠀⣼⢸⢃⠀⣿⡟⠀⠁⠟⠀⠑⢸⣿⢀⡎⢻⡇⣿⠁⢠⡄⠑⢤⠀⣴⣶⠄⠛⠰⠺⠆⢾⡇⡀⠈⣿⠀⣉⠁⠈⢀⠈⣼⣇⢀⣀⣀⣐⡂⠀",
"⠀⢠⡄⢸⣿⣿⣿⣿⠀⠋⡔⢸⣿⠸⠀⣛⠀⣿⠀⠀⠀⠀⠀⠀⢀⡀⠀⠁⠀⠙⢆⠻⣿⣇⠈⠄⣿⡦⠁⠀⠀⠁⡈⢀⠁⠀⠸⡇⠃⠸⢹⠐⠛⢣⠀⣿⡇⠘⢻⠈⣿⣿⣿⡇⠀",
"⠴⠿⠇⢸⣿⣿⣿⣿⣀⣾⡇⢸⣿⣧⢸⠟⠃⠙⠀⣦⠀⣴⣾⣿⣿⣛⠉⠂⣴⡈⢺⣷⡙⢿⣆⠃⢸⡁⠀⣀⡐⠛⢷⣿⣷⣦⡄⢀⡴⠀⠃⠘⣏⣼⠐⣿⡇⡀⠀⢠⣿⣿⣿⡇⠀",
"⠀⠀⠀⢸⣿⣿⣿⣿⣿⡟⣠⣿⣿⠇⣼⢨⠉⡀⠀⢸⣷⣿⣿⣿⠛⠿⠁⠀⠸⣿⣴⣿⣿⣶⣌⡀⢊⣴⡟⠻⠟⠀⠀⢹⣿⣿⣃⣾⠇⠀⣼⡇⣿⡿⢀⣿⡇⣷⣴⣿⣿⣿⣿⡇⠀",
"⠀⠀⡀⢸⡟⢿⠿⠿⠃⠐⠛⠉⢭⠄⠹⣿⡄⠻⣄⡈⣿⣿⣧⡙⠄⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⡼⢟⣿⣿⡿⠀⠼⢋⣴⠿⠁⢘⠛⠧⢸⣿⣿⣿⣿⣿⣷⣿",
"⠄⠀⠃⠀⠻⠀⠀⢠⣶⡶⠶⣦⠤⠾⠧⠈⠛⢷⣤⣁⠸⣿⣿⣿⣶⣤⣤⣶⣾⣿⣿⣿⠉⣿⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣿⣿⣿⡇⣶⣶⠟⠁⠀⢠⠀⠀⠀⢀⣤⣤⣭⣭⣽⣏⣿",
"⠀⠁⠀⢠⡄⠘⠀⠀⢍⢛⠀⠈⠁⠀⠀⣶⠀⠀⣙⠛⠃⠀⣶⣶⢸⣿⣿⣿⣿⣿⣿⡄⠰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢁⡍⠁⢰⣿⣶⡌⠁⠀⠀⠸⢿⣿⣿⣿⣿⣿⣿",
"⠀⠉⠁⠈⢀⣄⡀⠈⠀⠴⠧⣼⠆⠀⠀⠁⠀⠀⠈⢀⣶⠀⢿⣿⡎⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢋⡉⢿⡿⢃⠀⠁⠀⢠⣦⡀⠁⢸⣿⣶⣷⣦⣿⣿⠛⣿⣿⣿",
"⠀⣦⡤⠀⠀⡉⠁⢄⠀⠀⠀⢀⡄⠀⠀⢠⣤⡀⢀⣈⠀⠀⠈⠛⢿⠆⣻⣿⣿⣿⣿⣟⡛⠿⣿⣿⣿⣿⣿⣿⣧⠸⡿⠟⠀⢠⠏⢠⠒⢠⣄⠃⠀⢀⣈⡁⢬⠟⢻⣿⣷⠶⢿⡇⠀",
"⠤⠀⠀⠘⠆⢿⠀⠀⠀⠀⠀⠈⠁⣄⡀⠈⠅⠀⠀⠰⡶⢀⣄⢤⠀⠈⠛⢿⣿⣿⣿⣿⣛⢳⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⣶⡆⠠⣄⣀⠀⠻⠯⠃⠀⠐⠏⣿⣿⠿⣿⡿⠲",
"⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⢀⣉⠀⠀⢀⣤⣤⣤⣴⣿⡏⠘⠀⠀⠂⠀⠈⠙⠻⢿⣿⣿⣿⣿⡿⠛⣩⣴⣶⡀⠀⠸⠁⠂⠀⡏⣿⣧⡈⠛⠓⠀⠀⠀⣴⣤⠾⣤⠛⣶⣷⣷⣴",
"⠀⠀⠀⠈⢿⠟⠀⠀⠀⠀⠀⠀⠉⠋⠀⠀⣾⣿⣿⣿⣿⣿⣷⠸⣆⠀⠀⠀⣶⣧⣹⣶⣬⣉⣉⣡⣶⣿⣿⣿⣿⣿⠃⠀⠀⠀⡀⢠⣿⣿⣿⣶⣾⣿⣷⣦⡈⣡⣄⢸⡿⣿⣿⡿⣏",
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⣡⣶⣿⣿⣇⠹⣿⣿⣿⣿⣿⣿⡆⢻⣦⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⡤⠂⢀⡴⢡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠻⠤⣉⣿⣿⣍⣙",
"⢀⠀⣈⣁⠐⢦⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣆⠻⣿⣿⣿⣿⣿⣿⡄⢿⣦⡀⠘⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⡔⠂⢀⣴⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⡿⠛⣡⣴⣶⣤⡁⠈⠛⣿⣿",
"⣾⠉⠀⠉⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣦⡙⢿⣄⠀⠀⢉⠻⣿⣿⣿⠟⡁⠀⠀⣠⠶⠛⣡⣴⣿⣿⣿⣿⣟⣻⡿⠟⣩⣴⣿⣿⣿⣿⣿⣿⣦⠀⠹⠳",
"⠉⠀⠀⠀⠀⣴⣿⣿⣿⣿⡇⠘⣿⣿⣿⣿⣿⣿⡿⠦⠙⠻⣿⣿⣿⣿⣿⣶⣤⣅⡀⠘⠓⠄⠉⠥⡺⠁⣀⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⡟⢋⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀",
"⣀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣇⠀⢻⡻⠸⠿⢋⣡⣶⣾⣶⣶⣶⣶⣬⡙⠻⢿⡿⠿⣿⣆⠹⣿⣿⡟⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢉⣴⣿⣿⣿⣿⣿⣿⣿⠙⣿⣿⣿⣿⣿⡇⠀",
"⣉⣀⣴⣿⣿⣿⣿⣿⣿⣿⠛⣠⣶⣦⣀⠿⣿⣿⣿⠿⠿⠿⠿⠿⠿⣿⣷⣦⣄⠀⣀⡙⠇⢹⣿⢣⡿⠛⠉⠼⠛⠛⠛⣛⣛⣉⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⣿⣿⣿⣿⣿⣧⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⠛⢁⣬⣿⣿⣿⣿⣷⣌⡉⠀⣠⢤⢴⡦⠠⣬⣄⣈⡉⠤⢾⡿⢿⡶⢠⠀⢤⣤⠶⠀⠀⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢀⣿⣿⣿⣿⣿⣿⠀",
],
    "killua3": [
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣛⠛⢭⣭⣽⣛⡛⠛⠿⣿⣿⣿⣿⣿⢉⡙⢿⣿⡛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣙⠛⠒⠮⠙⢿⣿⣿⣿⣶⣮⣍⡛⢿⡇⣿⣦⡙⣧⢱⡘⣿⣿⣿⣿⢏⣴⢸⣿⣿⣿⣿⣿⢸⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡍⢉⣉⣉⣉⣉⣉⣉⣁⣙⠳⣶⣦⣽⣿⣿⣿⣿⣿⣿⣶⡅⢻⣿⣷⡈⢸⣷⠘⣿⠟⣡⣿⣿⢸⣿⡏⣉⣿⣽⠘⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⣿⡆⣱⣾⣿⣿⠇⠼⢛⣡⣤⣤⣤⣤⠤⠈⢹⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⢃⣙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⠏⣠⣾⣿⣿⣿⣿⡿⢁⣰⣻⣥⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢛⣩⣵⣶⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⡟⠠⢤⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠏⡥⡾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡙⢿⣿⣿⣿⣿⣿⣿⣿⡟⠀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⠶⠷⢒⣀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣿⣿⣿⡇⡄⣿⣿⣿⠋⣿⣿⣿⣿⣿⣏⣁⣀⠀⠆⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣀⠲⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⢄⣒⣛⣛⢦⠻⠛⡱⢃⡿⢟⡁⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣷⣮⣝⡛⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⣴⣾⣿⣿⣿⣿⣦⡐⣤⡐⢒⣒⣩⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⡿⠟⣛⣥⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡌⣷⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣴⣶⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⠀⢰⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⣿⠀⣿⣿⣿⣿⣟⠻⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣷⣌⠻⣷⣿⣿⣿⣿⣷⣾⣷⣶⢖⣨⣾⡿⠟⢩⣿⡿⠋⣼⣿⢿⣿⣿⣿⢃⣿⣿⠟⣿⣿⣿⢹⣿⣿⢏⣼⠟⣴⢿⣿⡿⣿⡏⢿⣦⡙⢿⣿⣿⣿⣿⠟⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣷⣬⡛⢿⣿⣿⣿⣿⣿⣯⣛⣭⣴⡾⣳⡿⢋⠀⣾⠟⣡⣿⣿⠿⠁⣾⣿⣿⠀⣿⣿⡇⠘⠋⢕⣛⣥⣾⣿⠈⢿⣧⠘⣿⣆⠻⣿⣮⠻⣍⡊⢡⣴⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⠿⢂⣭⣿⣿⣿⣿⣿⣿⣿⣿⣣⢏⣴⠟⣼⣧⡆⣿⣿⢏⠀⣼⣿⣿⠏⢀⣿⣿⠣⢰⣶⠘⣿⣿⣿⣿⣶⠘⣿⡆⢿⣿⡄⠝⢿⣧⠹⣿⣎⢻⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⡿⠵⠾⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣾⡿⣿⣿⣿⡡⠁⣸⣿⣿⠏⡖⢸⣿⣏⡄⡆⣿⡇⢻⡿⣿⣿⣿⡇⢻⣧⠸⣿⣿⢸⣆⢻⣇⢉⠻⡄⠃⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠟⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⡏⣸⣿⢃⣿⣿⠗⣠⢡⣿⡿⢫⡞⠀⣾⣿⡿⢡⡇⢸⡟⠀⣿⣿⠿⡿⢁⠸⣿⠀⢹⣿⡈⣿⣆⢻⠘⣷⡁⠀⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⡿⢁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢰⣿⣿⢸⣿⡟⣰⡇⣸⣿⡿⢂⡈⠐⠿⠿⠣⢞⠁⣉⠁⡇⣻⣯⡙⢁⣈⡄⡟⣸⡇⣿⢇⣿⣿⡆⡇⣹⣿⡆⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣀⣙⣛⣛⡻⠿⣿⣿⣿⣿⣿⡿⢃⣤⣤⡋⢸⣿⢱⣿⢱⣿⠟⣡⣿⢣⣿⠏⢴⣿⠛⣼⢃⣾⡇⣿⡿⢃⣾⠿⠃⠡⢿⠆⠸⢸⣿⣿⣧⢰⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣙⠻⣿⣿⢡⣴⣦⣌⠻⢸⣿⢸⣿⢈⡕⠚⡉⠀⢊⣀⡒⠶⠌⠀⣵⡿⢉⠀⢟⣵⣯⠕⢈⢀⣶⣿⢸⠀⠙⢿⣿⣿⠘⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡐⢤⣶⣶⣿⣿⢸⣿⣿⣿⠀⣧⠻⢸⣿⣿⣿⢙⠁⠴⢿⣿⣿⣷⣤⣼⡟⣱⣿⣴⣿⣿⣯⣾⣿⣿⣿⣿⢸⣿⡐⠲⣬⣉⡁⣹⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣬⣙⠻⠿⢆⠻⣝⢿⣧⡙⣃⡈⣿⣿⣿⣿⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⠈⡻⠧⠈⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⢼⡗⠌⠛⢦⣼⠿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣿⡿⣿⣿⣿⡿⠈⣿⣦⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⢡⣿⣦⠀⢀⠀⠹⣿⣿⣿⣿⣿⣿⡏⣶⣮⣭⣟⣛⣛⣛⣛⣻⣭⣭⡥⡂⣸⣿⡿⢁⣤⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⡆⠘⣽⡆⠈⠻⣿⣿⣿⣿⡇⢍⢫⣭⣽⣿⣿⣿⣿⠿⠛⣫⣭⣶⡿⢋⣰⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢡⡄⠙⣿⣆⠑⢌⡛⠿⣿⣿⣦⣭⣉⣉⣭⣭⣶⣶⣿⣿⣿⠟⢋⣴⣿⣿⣿⣿⣿⣿⡀⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⣋⣡⣶⣶⠹⣿⣄⠙⠿⣷⣄⡙⠻⢶⣭⣙⡻⠿⠿⣿⣿⣿⣿⣿⠟⢁⣐⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣛⣡⣴⣿⣿⣿⣿⣿⣦⡘⢿⣧⣷⣿⣿⣿⣷⣤⠤⣬⣍⣉⠋⠀⢠⣤⣤⠄⣰⣿⣿⣿⣿⣶⣤⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⣿⣿⣿⣿⣿⣿⣿⣿⠋⣡⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡙⢿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣷⣿⣿⡟⢡⣶⣿⣿⣿⣿⣿⣿⣿⣷⡈⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀",
"⠿⠿⠿⠿⠿⠿⠿⠃⠾⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠦⠹⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠀⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠧⠹⠿⠿⠿⠿⠿⠿⠿⠇⠀⠀⠀⠀⠀⠀",
],
}


# settings
def settings(userFiles):
    while True:
        clear()
        print("===== Settings Manager =====\n")
        print("Wallpaper")

        userInput = input("\n> ").lower()

        if userInput == "exit":
            break
        
        elif userInput == "wallpaper":
            clear()
            print("===== Wallpapers =====\n")
            print("Killua1")
            print("Killua2")
            print("Killua3")
            wallpaperInput = input("\nChoose a Wallpaper: ").lower()

            if wallpaperInput == "killua1":
                print("Wallpaper set to Killua1")
                wallpaper = "killua1"
            elif wallpaperInput == "killua2":
                print("Wallpaper set to Killua2")
                wallpaper = "killua2"
            elif wallpaperInput == "killua3":
                print("Wallpaper set to Killua3")
                wallpaper = "killua3"
            time.sleep(1)

            if not os.path.exists(os.path.join(userFiles, "wallpapers")):
                os.makedirs(os.path.join(userFiles, "wallpapers"))
            wallpapersFolder = os.path.join(userFiles, "wallpapers")
            with open(os.path.join(wallpapersFolder, "wallpaper_auswahl.pkl"), "wb") as file:
                pickle.dump(wallpaper, file)
            print(f"Wallpaper '{wallpaper}' saved")
            time.sleep(1)


# minesweeper
def generate_minesweeper_field(rows, cols, num_mines):
    field = [["0" for _ in range(cols)] for _ in range(rows)]
    mines = set()
    while len(mines) < num_mines:
        r = random.randint(0, rows - 1)
        c = random.randint(0, cols - 1)
        if (r, c) not in mines:
            mines.add((r, c))
            field[r][c] = "X"
    for r in range(rows):
        for c in range(cols):
            if field[r][c] == "X":
                continue
            count = 0
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols and field[nr][nc] == "X":
                        count += 1
            field[r][c] = "·" if count == 0 else str(count)
    return field

def print_field(field, revealed, flagged):
    cols = len(field[0])
    header = "  " + "".join(f"{i:2}" for i in range(cols))
    print(header)
    
    for r in range(len(field)):
        row = f"{r:2} "
        for c in range(len(field[r])):
            if flagged[r][c]:
                row += "⚐ "
            elif revealed[r][c]:
                row += field[r][c] + " "
            else:
                row += "■ "
        print(row)

def reveal(field, revealed, r, c):
    if revealed[r][c] or field[r][c] == "X":
        return
    revealed[r][c] = True
    if field[r][c] == "·":
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < len(field) and 0 <= nc < len(field[0]) and not revealed[nr][nc]:
                    reveal(field, revealed, nr, nc)

def minesweeper():
    while True:
        clear()
        print("===== Minesweeper =====\n")
        rows = int(input("Enter number of rows: "))
        if rows >= 11:
            rows = 10
        clear()
        print("===== Minesweeper =====\n")
        cols = int(input("Enter number of columns: "))
        if cols >= 11:
            cols = 10
        clear()
        print("===== Minesweeper =====\n")
        mines = int(input("Enter number of mines: "))
        if mines > rows*cols:
            mines = rows*cols-1
            time.sleep(1)
        else:
            break
        
    field = generate_minesweeper_field(rows, cols, mines)
    revealed = [[False for _ in range(cols)] for _ in range(rows)]
    flagged = [[False for _ in range(cols)] for _ in range(rows)]
    
    while True:
        clear()
        print("===== Minesweeper =====\n")
        print_field(field, revealed, flagged)
        
        try:
            action, row, col = input("Enter action (r)eveal or (f)lag with coords: ").lower().split()
            row, col = int(row), int(col)
            
            if 0 <= row < rows and 0 <= col < cols:
                if action.lower() == "f":
                    if not revealed[row][col]:
                        flagged[row][col] = not flagged[row][col]
                    else:
                        print("You cannot flag a revealed tile.")
                        time.sleep(1)
                elif action.lower() == "r":
                    if flagged[row][col]:
                        flagged[row][col] = False
                    if field[row][col] == "X":
                        revealed[row][col] = True
                        clear()
                        print_field(field, revealed, flagged)
                        print("You hit a mine!")
                        input("Press enter to exit ")
                        break
                    else:
                        reveal(field, revealed, row, col)
            else:
                print("Invalid input")
        except ValueError:
            print("Invalid input")
        
        if all((revealed[r][c] or field[r][c] == "X" or flagged[r][c]) for r in range(rows) for c in range(cols)):
            clear()
            print_field(field, revealed, flagged)
            print("You won!")
            input("Press enter to exit ")
            break
        