#!/bin/bash
python3 /home/maxi/Desktop/OS/boot/Bootloader.py
