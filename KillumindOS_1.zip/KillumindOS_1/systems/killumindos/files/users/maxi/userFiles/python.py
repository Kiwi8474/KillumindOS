def textPrint(text):
	print(text)

textPrint("Hello World")
textPrint("Test Test 123")
input("Press enter to exit")
