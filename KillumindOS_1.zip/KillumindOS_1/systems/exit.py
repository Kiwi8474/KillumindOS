import os
import time


print("Prozesse beendet.")
time.sleep(1)
for i in range(50):
    print(os.path.dirname)
    print(os.path.dirname(os.path.abspath(__file__)))
    time.sleep(0.01)